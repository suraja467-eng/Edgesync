'use client'

import { motion } from 'framer-motion'
import { ArrowUpRight, ArrowDownRight, ExternalLink } from 'lucide-react'
import { cn } from '@/lib/utils'

interface Trade {
  id: string
  symbol: string
  type: 'BUY' | 'SELL'
  entry: number
  exit: number
  lotSize: number
  pnl: number
  rr: number
  date: string
  time: string
}

const recentTrades: Trade[] = [
  { id: '1', symbol: 'EUR/USD', type: 'BUY', entry: 1.0845, exit: 1.0892, lotSize: 1.0, pnl: 470, rr: 2.3, date: '2024-01-15', time: '09:32' },
  { id: '2', symbol: 'GBP/JPY', type: 'SELL', entry: 187.450, exit: 186.980, lotSize: 0.5, pnl: 235, rr: 1.8, date: '2024-01-15', time: '11:45' },
  { id: '3', symbol: 'XAU/USD', type: 'BUY', entry: 2024.50, exit: 2018.30, lotSize: 0.3, pnl: -186, rr: -0.9, date: '2024-01-14', time: '14:22' },
  { id: '4', symbol: 'BTC/USD', type: 'SELL', entry: 42850, exit: 42340, lotSize: 0.1, pnl: 510, rr: 2.5, date: '2024-01-14', time: '08:15' },
  { id: '5', symbol: 'NAS100', type: 'BUY', entry: 16840, exit: 16925, lotSize: 0.2, pnl: 170, rr: 1.4, date: '2024-01-13', time: '15:30' },
  { id: '6', symbol: 'EUR/GBP', type: 'SELL', entry: 0.8612, exit: 0.8645, lotSize: 1.5, pnl: -495, rr: -1.2, date: '2024-01-13', time: '10:08' },
]

export function RecentTrades() {
  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-5 border-b border-border">
        <h3 className="font-semibold text-lg">Recent Trades</h3>
        <button className="text-sm text-primary hover:text-primary/80 flex items-center gap-1">
          View All
          <ExternalLink className="h-3.5 w-3.5" />
        </button>
      </div>

      {/* Table */}
      <div className="flex-1 overflow-auto">
        <table className="w-full">
          <thead className="sticky top-0 bg-card">
            <tr className="text-left text-xs text-muted-foreground border-b border-border">
              <th className="px-5 py-3 font-medium">Symbol</th>
              <th className="px-5 py-3 font-medium">Type</th>
              <th className="px-5 py-3 font-medium hidden sm:table-cell">Entry</th>
              <th className="px-5 py-3 font-medium hidden sm:table-cell">Exit</th>
              <th className="px-5 py-3 font-medium hidden md:table-cell">Lot</th>
              <th className="px-5 py-3 font-medium text-right">P&L</th>
              <th className="px-5 py-3 font-medium text-right hidden lg:table-cell">RR</th>
              <th className="px-5 py-3 font-medium text-right hidden xl:table-cell">Date</th>
            </tr>
          </thead>
          <tbody>
            {recentTrades.map((trade, index) => (
              <motion.tr
                key={trade.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="border-b border-border/50 hover:bg-muted/30 transition-colors cursor-pointer"
              >
                <td className="px-5 py-4">
                  <div className="flex items-center gap-2">
                    <div className={cn(
                      "h-8 w-8 rounded-lg flex items-center justify-center text-xs font-bold",
                      trade.pnl >= 0 
                        ? "bg-[var(--profit)]/15 text-[var(--profit)]" 
                        : "bg-[var(--loss)]/15 text-[var(--loss)]"
                    )}>
                      {trade.symbol.slice(0, 2)}
                    </div>
                    <span className="font-medium">{trade.symbol}</span>
                  </div>
                </td>
                <td className="px-5 py-4">
                  <span className={cn(
                    "inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium",
                    trade.type === 'BUY' 
                      ? "bg-[var(--profit)]/15 text-[var(--profit)]" 
                      : "bg-[var(--loss)]/15 text-[var(--loss)]"
                  )}>
                    {trade.type === 'BUY' ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                    {trade.type}
                  </span>
                </td>
                <td className="px-5 py-4 text-muted-foreground hidden sm:table-cell font-mono text-sm">
                  {trade.entry}
                </td>
                <td className="px-5 py-4 text-muted-foreground hidden sm:table-cell font-mono text-sm">
                  {trade.exit}
                </td>
                <td className="px-5 py-4 text-muted-foreground hidden md:table-cell">
                  {trade.lotSize}
                </td>
                <td className={cn(
                  "px-5 py-4 text-right font-semibold",
                  trade.pnl >= 0 ? "text-[var(--profit)]" : "text-[var(--loss)]"
                )}>
                  {trade.pnl >= 0 ? '+' : ''}${trade.pnl.toFixed(2)}
                </td>
                <td className={cn(
                  "px-5 py-4 text-right font-medium hidden lg:table-cell",
                  trade.rr >= 0 ? "text-[var(--profit)]" : "text-[var(--loss)]"
                )}>
                  {trade.rr >= 0 ? '+' : ''}{trade.rr.toFixed(1)}R
                </td>
                <td className="px-5 py-4 text-right text-muted-foreground text-sm hidden xl:table-cell">
                  <div>{trade.date}</div>
                  <div className="text-xs">{trade.time}</div>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
