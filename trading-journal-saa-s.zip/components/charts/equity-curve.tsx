'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts'
import { cn } from '@/lib/utils'

const generateEquityData = (days: number) => {
  const data = []
  let balance = 10000
  const startDate = new Date()
  startDate.setDate(startDate.getDate() - days)

  for (let i = 0; i < days; i++) {
    const change = (Math.random() - 0.45) * 500
    balance = Math.max(balance + change, 5000)
    const date = new Date(startDate)
    date.setDate(date.getDate() + i)
    data.push({
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      balance: Math.round(balance * 100) / 100,
      pnl: Math.round(change * 100) / 100,
    })
  }
  return data
}

const timeFilters = [
  { label: '1W', days: 7 },
  { label: '1M', days: 30 },
  { label: '3M', days: 90 },
  { label: '1Y', days: 365 },
  { label: 'All', days: 730 },
]

export function EquityCurve() {
  const [activeFilter, setActiveFilter] = useState('1M')
  const days = timeFilters.find(f => f.label === activeFilter)?.days || 30
  const data = generateEquityData(days)
  
  const startBalance = data[0]?.balance || 10000
  const endBalance = data[data.length - 1]?.balance || 10000
  const totalChange = endBalance - startBalance
  const percentChange = ((totalChange / startBalance) * 100).toFixed(2)
  const isPositive = totalChange >= 0

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 border-b border-border">
        <div>
          <h3 className="font-semibold text-lg mb-1">Equity Curve</h3>
          <div className="flex items-baseline gap-3">
            <span className="text-2xl font-bold">${endBalance.toLocaleString()}</span>
            <span className={cn(
              "text-sm font-medium px-2 py-0.5 rounded-full",
              isPositive ? "bg-[var(--profit)]/15 text-[var(--profit)]" : "bg-[var(--loss)]/15 text-[var(--loss)]"
            )}>
              {isPositive ? '+' : ''}{percentChange}%
            </span>
          </div>
        </div>
        
        {/* Time filters */}
        <div className="flex gap-1 bg-muted/50 p-1 rounded-lg">
          {timeFilters.map((filter) => (
            <button
              key={filter.label}
              onClick={() => setActiveFilter(filter.label)}
              className={cn(
                "px-3 py-1.5 rounded-md text-sm font-medium transition-all",
                activeFilter === filter.label
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Chart */}
      <div className="flex-1 p-5 min-h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={isPositive ? "rgb(74, 222, 128)" : "rgb(248, 113, 113)"} stopOpacity={0.3} />
                <stop offset="100%" stopColor={isPositive ? "rgb(74, 222, 128)" : "rgb(248, 113, 113)"} stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
            <XAxis 
              dataKey="date" 
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 12 }}
              tickMargin={10}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 12 }}
              tickFormatter={(value) => `$${(value / 1000).toFixed(0)}k`}
              tickMargin={10}
              domain={['dataMin - 500', 'dataMax + 500']}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(20, 24, 32, 0.95)',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '12px',
                boxShadow: '0 10px 40px rgba(0,0,0,0.5)',
              }}
              labelStyle={{ color: 'rgba(255,255,255,0.7)', marginBottom: '8px' }}
              formatter={(value: number) => [`$${value.toLocaleString()}`, 'Balance']}
            />
            <Area
              type="monotone"
              dataKey="balance"
              stroke={isPositive ? "rgb(74, 222, 128)" : "rgb(248, 113, 113)"}
              strokeWidth={2}
              fill="url(#equityGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  )
}
