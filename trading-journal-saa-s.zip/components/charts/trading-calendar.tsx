'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { cn } from '@/lib/utils'

interface DayData {
  date: Date
  pnl: number
  trades: number
}

const generateCalendarData = () => {
  const data: Record<string, DayData> = {}
  const today = new Date()
  
  for (let i = 0; i < 60; i++) {
    const date = new Date(today)
    date.setDate(date.getDate() - i)
    
    if (Math.random() > 0.3) {
      const pnl = (Math.random() - 0.45) * 1000
      data[date.toISOString().split('T')[0]] = {
        date,
        pnl: Math.round(pnl * 100) / 100,
        trades: Math.floor(Math.random() * 8) + 1,
      }
    }
  }
  
  return data
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']

export function TradingCalendar() {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDay, setSelectedDay] = useState<DayData | null>(null)
  const calendarData = generateCalendarData()

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()

  const firstDayOfMonth = new Date(year, month, 1)
  const lastDayOfMonth = new Date(year, month + 1, 0)
  const startingDayOfWeek = firstDayOfMonth.getDay()
  const daysInMonth = lastDayOfMonth.getDate()

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1))
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1))

  const getDayData = (day: number) => {
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
    return calendarData[dateStr]
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-5 border-b border-border">
        <h3 className="font-semibold text-lg">Trading Calendar</h3>
        <div className="flex items-center gap-2">
          <button
            onClick={prevMonth}
            className="p-2 rounded-lg hover:bg-muted transition-colors"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <span className="text-sm font-medium min-w-[140px] text-center">
            {MONTHS[month]} {year}
          </span>
          <button
            onClick={nextMonth}
            className="p-2 rounded-lg hover:bg-muted transition-colors"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Calendar grid */}
      <div className="flex-1 p-5">
        {/* Day headers */}
        <div className="grid grid-cols-7 gap-1 mb-2">
          {DAYS.map((day) => (
            <div key={day} className="text-center text-xs text-muted-foreground font-medium py-2">
              {day}
            </div>
          ))}
        </div>

        {/* Calendar days */}
        <div className="grid grid-cols-7 gap-1">
          {/* Empty cells for days before the first day of month */}
          {Array.from({ length: startingDayOfWeek }).map((_, i) => (
            <div key={`empty-${i}`} className="aspect-square" />
          ))}

          {/* Days of the month */}
          {Array.from({ length: daysInMonth }).map((_, i) => {
            const day = i + 1
            const dayData = getDayData(day)
            const isToday = new Date().toDateString() === new Date(year, month, day).toDateString()
            
            return (
              <motion.button
                key={day}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => dayData && setSelectedDay(dayData)}
                className={cn(
                  "aspect-square rounded-lg flex flex-col items-center justify-center text-sm transition-all relative",
                  dayData ? (
                    dayData.pnl >= 0 
                      ? "bg-[var(--profit)]/15 hover:bg-[var(--profit)]/25 text-[var(--profit)]"
                      : "bg-[var(--loss)]/15 hover:bg-[var(--loss)]/25 text-[var(--loss)]"
                  ) : "hover:bg-muted/50",
                  isToday && "ring-2 ring-primary ring-offset-2 ring-offset-background"
                )}
              >
                <span className={cn(
                  "font-medium",
                  !dayData && "text-muted-foreground"
                )}>
                  {day}
                </span>
                {dayData && (
                  <span className="text-[10px] opacity-80">
                    {dayData.pnl >= 0 ? '+' : ''}{dayData.pnl > 999 || dayData.pnl < -999 
                      ? `${(dayData.pnl / 1000).toFixed(1)}k` 
                      : dayData.pnl.toFixed(0)}
                  </span>
                )}
              </motion.button>
            )
          })}
        </div>
      </div>

      {/* Selected day popup */}
      {selectedDay && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 border-t border-border bg-muted/30"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">
                {selectedDay.date.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })}
              </p>
              <p className={cn(
                "text-xl font-bold",
                selectedDay.pnl >= 0 ? "text-[var(--profit)]" : "text-[var(--loss)]"
              )}>
                {selectedDay.pnl >= 0 ? '+' : ''}${selectedDay.pnl.toFixed(2)}
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Trades</p>
              <p className="text-xl font-bold">{selectedDay.trades}</p>
            </div>
            <button
              onClick={() => setSelectedDay(null)}
              className="text-muted-foreground hover:text-foreground"
            >
              &times;
            </button>
          </div>
        </motion.div>
      )}
    </div>
  )
}
