'use client'

import { motion } from 'framer-motion'
import { TrendingUp, TrendingDown, Trophy, AlertTriangle, Zap, Target } from 'lucide-react'
import { cn } from '@/lib/utils'

interface QuickStatProps {
  title: string
  value: string
  subtitle?: string
  icon: React.ElementType
  type: 'positive' | 'negative' | 'neutral'
  delay?: number
}

function QuickStat({ title, value, subtitle, icon: Icon, type, delay = 0 }: QuickStatProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay }}
      whileHover={{ scale: 1.02 }}
      className={cn(
        "p-4 rounded-xl border transition-all",
        type === 'positive' && "bg-[var(--profit)]/5 border-[var(--profit)]/20",
        type === 'negative' && "bg-[var(--loss)]/5 border-[var(--loss)]/20",
        type === 'neutral' && "bg-primary/5 border-primary/20"
      )}
    >
      <div className="flex items-start justify-between mb-2">
        <Icon className={cn(
          "h-5 w-5",
          type === 'positive' && "text-[var(--profit)]",
          type === 'negative' && "text-[var(--loss)]",
          type === 'neutral' && "text-primary"
        )} />
      </div>
      <p className="text-sm text-muted-foreground mb-1">{title}</p>
      <p className={cn(
        "text-lg font-bold",
        type === 'positive' && "text-[var(--profit)]",
        type === 'negative' && "text-[var(--loss)]",
        type === 'neutral' && "text-foreground"
      )}>
        {value}
      </p>
      {subtitle && (
        <p className="text-xs text-muted-foreground mt-1">{subtitle}</p>
      )}
    </motion.div>
  )
}

export function PerformanceWidgets() {
  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-5 border-b border-border">
        <h3 className="font-semibold text-lg">Quick Stats</h3>
      </div>

      {/* Widgets Grid */}
      <div className="flex-1 p-5 grid grid-cols-2 gap-3">
        <QuickStat
          title="Best Day"
          value="+$1,247"
          subtitle="Jan 12, 2024"
          icon={Trophy}
          type="positive"
          delay={0}
        />
        <QuickStat
          title="Worst Day"
          value="-$892"
          subtitle="Jan 8, 2024"
          icon={AlertTriangle}
          type="negative"
          delay={0.1}
        />
        <QuickStat
          title="Win Streak"
          value="7 trades"
          subtitle="Current"
          icon={Zap}
          type="positive"
          delay={0.2}
        />
        <QuickStat
          title="Lose Streak"
          value="3 trades"
          subtitle="Max this month"
          icon={Target}
          type="negative"
          delay={0.3}
        />
      </div>
    </div>
  )
}
