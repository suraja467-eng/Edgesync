'use client'

import { motion } from 'framer-motion'
import { cn } from '@/lib/utils'
import { LucideIcon } from 'lucide-react'

interface StatsCardProps {
  title: string
  value: string | number
  change?: string
  changeType?: 'positive' | 'negative' | 'neutral'
  icon: LucideIcon
  delay?: number
}

export function StatsCard({ title, value, change, changeType = 'neutral', icon: Icon, delay = 0 }: StatsCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      whileHover={{ y: -2, transition: { duration: 0.2 } }}
      className="relative overflow-hidden rounded-2xl bg-card border border-border p-5 group"
    >
      {/* Background glow effect */}
      <div className={cn(
        "absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500",
        changeType === 'positive' && "bg-gradient-to-br from-[var(--profit)]/10 to-transparent",
        changeType === 'negative' && "bg-gradient-to-br from-[var(--loss)]/10 to-transparent",
        changeType === 'neutral' && "bg-gradient-to-br from-primary/10 to-transparent"
      )} />
      
      <div className="relative">
        <div className="flex items-start justify-between mb-3">
          <div className={cn(
            "h-10 w-10 rounded-xl flex items-center justify-center",
            changeType === 'positive' && "bg-[var(--profit)]/15 text-[var(--profit)]",
            changeType === 'negative' && "bg-[var(--loss)]/15 text-[var(--loss)]",
            changeType === 'neutral' && "bg-primary/15 text-primary"
          )}>
            <Icon className="h-5 w-5" />
          </div>
          {change && (
            <span className={cn(
              "text-xs font-medium px-2 py-1 rounded-full",
              changeType === 'positive' && "bg-[var(--profit)]/15 text-[var(--profit)]",
              changeType === 'negative' && "bg-[var(--loss)]/15 text-[var(--loss)]",
              changeType === 'neutral' && "bg-muted text-muted-foreground"
            )}>
              {change}
            </span>
          )}
        </div>
        
        <p className="text-sm text-muted-foreground mb-1">{title}</p>
        <p className="text-2xl font-bold tracking-tight">{value}</p>
      </div>
    </motion.div>
  )
}

interface GlassCardProps {
  children: React.ReactNode
  className?: string
  delay?: number
}

export function GlassCard({ children, className, delay = 0 }: GlassCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className={cn(
        "rounded-2xl bg-card border border-border overflow-hidden",
        className
      )}
    >
      {children}
    </motion.div>
  )
}

export function CardHeader({ 
  title, 
  action,
  className 
}: { 
  title: string
  action?: React.ReactNode
  className?: string 
}) {
  return (
    <div className={cn("flex items-center justify-between p-5 border-b border-border", className)}>
      <h3 className="font-semibold text-lg">{title}</h3>
      {action}
    </div>
  )
}
