'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Sparkles,
  FileText,
  Brain,
  Target,
  Calendar,
  MessageSquare,
  Loader2,
  Copy,
  Check,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Lightbulb,
  Download,
  History
} from 'lucide-react'
import { cn } from '@/lib/utils'

// Sample trading data - in production this would come from your database
const sampleTradingData = {
  totalTrades: 47,
  winningTrades: 29,
  losingTrades: 18,
  winRate: 61.7,
  totalPnL: 4250.50,
  averageWin: 285.30,
  averageLoss: -142.75,
  profitFactor: 2.0,
  maxDrawdown: -1250.00,
  sharpeRatio: 1.85,
  averageRR: 2.1,
  bestTrade: { symbol: 'EURUSD', pnl: 580.00, rr: 3.5 },
  worstTrade: { symbol: 'GBPJPY', pnl: -320.00, rr: -1.2 },
  tradingDays: 22,
  averageTradesPerDay: 2.1,
  sessionsBreakdown: {
    london: { trades: 18, winRate: 72.2, pnl: 2100 },
    newYork: { trades: 15, winRate: 60.0, pnl: 1450 },
    asian: { trades: 10, winRate: 50.0, pnl: 450 },
    overlap: { trades: 4, winRate: 75.0, pnl: 250 }
  },
  instrumentBreakdown: {
    'EURUSD': { trades: 15, winRate: 66.7, pnl: 1800 },
    'GBPUSD': { trades: 12, winRate: 58.3, pnl: 950 },
    'XAUUSD': { trades: 10, winRate: 60.0, pnl: 1100 },
    'USDJPY': { trades: 6, winRate: 50.0, pnl: 250 },
    'BTCUSD': { trades: 4, winRate: 75.0, pnl: 150 }
  },
  recentTrades: [
    { date: '2024-01-15', symbol: 'EURUSD', type: 'BUY', pnl: 245.50, rr: 2.5 },
    { date: '2024-01-15', symbol: 'GBPUSD', type: 'SELL', pnl: -85.00, rr: -0.8 },
    { date: '2024-01-14', symbol: 'XAUUSD', type: 'BUY', pnl: 380.00, rr: 3.2 },
    { date: '2024-01-14', symbol: 'USDJPY', type: 'SELL', pnl: 125.00, rr: 1.5 },
    { date: '2024-01-13', symbol: 'EURUSD', type: 'BUY', pnl: -120.00, rr: -1.0 }
  ],
  weeklyPnL: [1200, -350, 890, 1100, -200, 1610],
  emotionLogs: ['Calm', 'Anxious', 'Confident', 'FOMO', 'Calm', 'Frustrated'],
  followedPlan: [true, false, true, true, false, true]
}

const reportTypes = [
  {
    id: 'performance',
    name: 'Performance Report',
    description: 'Comprehensive analysis of your trading performance metrics',
    icon: TrendingUp,
    color: 'from-emerald-500/20 to-emerald-500/5',
    borderColor: 'border-emerald-500/30',
    iconColor: 'text-emerald-400'
  },
  {
    id: 'psychology',
    name: 'Psychology Analysis',
    description: 'Deep dive into your trading psychology and emotional patterns',
    icon: Brain,
    color: 'from-purple-500/20 to-purple-500/5',
    borderColor: 'border-purple-500/30',
    iconColor: 'text-purple-400'
  },
  {
    id: 'strategy',
    name: 'Strategy Review',
    description: 'Evaluate your trading strategy effectiveness and optimization',
    icon: Target,
    color: 'from-blue-500/20 to-blue-500/5',
    borderColor: 'border-blue-500/30',
    iconColor: 'text-blue-400'
  },
  {
    id: 'weekly',
    name: 'Weekly Summary',
    description: 'Detailed weekly trading journal and progress report',
    icon: Calendar,
    color: 'from-amber-500/20 to-amber-500/5',
    borderColor: 'border-amber-500/30',
    iconColor: 'text-amber-400'
  }
]

const previousReports = [
  { id: 1, type: 'Performance Report', date: '2024-01-14', preview: 'Overall strong performance with 61.7% win rate...' },
  { id: 2, type: 'Psychology Analysis', date: '2024-01-12', preview: 'Emotional discipline has improved significantly...' },
  { id: 3, type: 'Weekly Summary', date: '2024-01-07', preview: 'Best week of the month with $1,610 profit...' },
]

export default function AIReportsPage() {
  const [selectedReport, setSelectedReport] = useState<string | null>(null)
  const [customPrompt, setCustomPrompt] = useState('')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedReport, setGeneratedReport] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const generateReport = async (reportType: string) => {
    setIsGenerating(true)
    setGeneratedReport(null)
    setError(null)
    setSelectedReport(reportType)

    try {
      const response = await fetch('/api/ai-report', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          tradingData: sampleTradingData,
          reportType,
          customPrompt: reportType === 'custom' ? customPrompt : undefined
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate report')
      }

      setGeneratedReport(data.report)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred')
    } finally {
      setIsGenerating(false)
    }
  }

  const copyToClipboard = async () => {
    if (generatedReport) {
      await navigator.clipboard.writeText(generatedReport)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const formatReport = (text: string) => {
    // Convert markdown-style formatting to HTML
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong class="text-foreground">$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/^### (.*$)/gim, '<h3 class="text-lg font-semibold text-foreground mt-6 mb-3">$1</h3>')
      .replace(/^## (.*$)/gim, '<h2 class="text-xl font-bold text-foreground mt-8 mb-4">$1</h2>')
      .replace(/^# (.*$)/gim, '<h1 class="text-2xl font-bold text-foreground mt-8 mb-4">$1</h1>')
      .replace(/^- (.*$)/gim, '<li class="ml-4 text-muted-foreground">$1</li>')
      .replace(/^\d+\. (.*$)/gim, '<li class="ml-4 text-muted-foreground list-decimal">$1</li>')
      .replace(/\n/g, '<br />')
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
            <Sparkles className="h-8 w-8 text-primary" />
            AI Reports
          </h1>
          <p className="text-muted-foreground mt-1">
            Generate intelligent insights and analysis powered by Gemini AI
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="px-4 py-2 rounded-xl bg-primary/10 border border-primary/20">
            <span className="text-sm font-medium text-primary">Powered by Gemini</span>
          </div>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 rounded-xl bg-card border border-border"
        >
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
            <TrendingUp className="h-4 w-4 text-profit" />
            Win Rate
          </div>
          <p className="text-2xl font-bold text-foreground">{sampleTradingData.winRate}%</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-4 rounded-xl bg-card border border-border"
        >
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
            <FileText className="h-4 w-4 text-primary" />
            Total Trades
          </div>
          <p className="text-2xl font-bold text-foreground">{sampleTradingData.totalTrades}</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-4 rounded-xl bg-card border border-border"
        >
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
            <Target className="h-4 w-4 text-amber-400" />
            Profit Factor
          </div>
          <p className="text-2xl font-bold text-foreground">{sampleTradingData.profitFactor}</p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="p-4 rounded-xl bg-card border border-border"
        >
          <div className="flex items-center gap-2 text-muted-foreground text-sm mb-1">
            <TrendingDown className="h-4 w-4 text-loss" />
            Max Drawdown
          </div>
          <p className="text-2xl font-bold text-loss">${Math.abs(sampleTradingData.maxDrawdown).toFixed(0)}</p>
        </motion.div>
      </div>

      {/* Report Types Grid */}
      <div>
        <h2 className="text-xl font-semibold text-foreground mb-4">Select Report Type</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {reportTypes.map((report, index) => (
            <motion.button
              key={report.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => generateReport(report.id)}
              disabled={isGenerating}
              className={cn(
                "p-6 rounded-xl bg-gradient-to-br text-left transition-all duration-200 border",
                report.color,
                report.borderColor,
                selectedReport === report.id && "ring-2 ring-primary",
                isGenerating && "opacity-50 cursor-not-allowed"
              )}
            >
              <div className={cn("h-12 w-12 rounded-xl bg-background/50 flex items-center justify-center mb-4", report.iconColor)}>
                <report.icon className="h-6 w-6" />
              </div>
              <h3 className="font-semibold text-foreground mb-1">{report.name}</h3>
              <p className="text-sm text-muted-foreground">{report.description}</p>
            </motion.button>
          ))}
        </div>
      </div>

      {/* Custom Prompt */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="p-6 rounded-xl bg-card border border-border"
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <MessageSquare className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground">Custom Analysis</h3>
            <p className="text-sm text-muted-foreground">Ask anything about your trading data</p>
          </div>
        </div>
        <div className="flex gap-3">
          <input
            type="text"
            value={customPrompt}
            onChange={(e) => setCustomPrompt(e.target.value)}
            placeholder="e.g., What patterns do you see in my losing trades?"
            className="flex-1 px-4 py-3 rounded-xl bg-background border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
          />
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => generateReport('custom')}
            disabled={isGenerating || !customPrompt.trim()}
            className="px-6 py-3 rounded-xl bg-primary text-primary-foreground font-medium hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            {isGenerating ? (
              <Loader2 className="h-5 w-5 animate-spin" />
            ) : (
              <Sparkles className="h-5 w-5" />
            )}
            Generate
          </motion.button>
        </div>
      </motion.div>

      {/* Generated Report */}
      <AnimatePresence mode="wait">
        {(isGenerating || generatedReport || error) && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="p-6 rounded-xl bg-card border border-border"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-xl bg-primary/20 flex items-center justify-center">
                  {isGenerating ? (
                    <Loader2 className="h-5 w-5 text-primary animate-spin" />
                  ) : error ? (
                    <AlertTriangle className="h-5 w-5 text-loss" />
                  ) : (
                    <Lightbulb className="h-5 w-5 text-primary" />
                  )}
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">
                    {isGenerating ? 'Generating Report...' : error ? 'Error' : 'AI Analysis Report'}
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {isGenerating
                      ? 'Analyzing your trading data with Gemini AI'
                      : error
                      ? 'Something went wrong'
                      : `Generated on ${new Date().toLocaleDateString()}`}
                  </p>
                </div>
              </div>
              {generatedReport && (
                <div className="flex items-center gap-2">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={copyToClipboard}
                    className="p-2 rounded-lg bg-background border border-border hover:bg-muted transition-colors"
                  >
                    {copied ? (
                      <Check className="h-5 w-5 text-profit" />
                    ) : (
                      <Copy className="h-5 w-5 text-muted-foreground" />
                    )}
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => selectedReport && generateReport(selectedReport)}
                    className="p-2 rounded-lg bg-background border border-border hover:bg-muted transition-colors"
                  >
                    <RefreshCw className="h-5 w-5 text-muted-foreground" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="p-2 rounded-lg bg-background border border-border hover:bg-muted transition-colors"
                  >
                    <Download className="h-5 w-5 text-muted-foreground" />
                  </motion.button>
                </div>
              )}
            </div>

            {isGenerating && (
              <div className="space-y-3">
                <div className="h-4 bg-muted rounded animate-pulse w-full" />
                <div className="h-4 bg-muted rounded animate-pulse w-3/4" />
                <div className="h-4 bg-muted rounded animate-pulse w-5/6" />
                <div className="h-4 bg-muted rounded animate-pulse w-2/3" />
                <div className="h-4 bg-muted rounded animate-pulse w-full" />
                <div className="h-4 bg-muted rounded animate-pulse w-4/5" />
              </div>
            )}

            {error && (
              <div className="p-4 rounded-xl bg-loss/10 border border-loss/20">
                <p className="text-loss">{error}</p>
                <p className="text-sm text-muted-foreground mt-2">
                  Please make sure your Gemini API key is configured correctly.
                </p>
              </div>
            )}

            {generatedReport && (
              <div
                className="prose prose-invert max-w-none text-muted-foreground leading-relaxed"
                dangerouslySetInnerHTML={{ __html: formatReport(generatedReport) }}
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Previous Reports */}
      <div>
        <div className="flex items-center gap-3 mb-4">
          <History className="h-5 w-5 text-muted-foreground" />
          <h2 className="text-xl font-semibold text-foreground">Recent Reports</h2>
        </div>
        <div className="space-y-3">
          {previousReports.map((report, index) => (
            <motion.div
              key={report.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="p-4 rounded-xl bg-card border border-border hover:border-primary/30 transition-all cursor-pointer"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <FileText className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-medium text-foreground">{report.type}</h4>
                    <p className="text-sm text-muted-foreground">{report.date}</p>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground max-w-md truncate hidden md:block">
                  {report.preview}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Tips Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-6 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20"
      >
        <div className="flex items-start gap-4">
          <div className="h-12 w-12 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
            <Lightbulb className="h-6 w-6 text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-2">Pro Tips for Better Reports</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Log your trades consistently for more accurate AI analysis
              </li>
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Include emotions and market notes in your journal entries
              </li>
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Generate weekly reports to track your progress over time
              </li>
              <li className="flex items-center gap-2">
                <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                Use custom prompts to get specific insights on problem areas
              </li>
            </ul>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
