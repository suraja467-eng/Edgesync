'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Plus,
  Search,
  Calendar,
  Tag,
  Image,
  Brain,
  Smile,
  Frown,
  Meh,
  AlertTriangle,
  CheckCircle2,
  Lightbulb,
  X,
  ChevronLeft,
  ChevronRight,
  Sparkles,
  Bold,
  Italic,
  List,
  ListOrdered,
  Quote
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { GlassCard } from '@/components/ui/stats-card'

interface JournalEntry {
  id: string
  date: string
  title: string
  mood: 'great' | 'good' | 'neutral' | 'bad' | 'terrible'
  content: string
  mistakes: string[]
  wins: string[]
  lessons: string[]
  tags: string[]
  screenshots: string[]
}

const mockEntries: JournalEntry[] = [
  {
    id: '1',
    date: '2024-01-15',
    title: 'Great Trading Day - Stuck to Plan',
    mood: 'great',
    content: 'Today was an excellent day. I followed my trading plan perfectly and took 3 high-quality setups. The key was patience - I waited for proper confirmations before entering.',
    mistakes: [],
    wins: ['Followed trading plan 100%', 'Took profits at targets', 'No revenge trading'],
    lessons: ['Patience pays off', 'Quality over quantity'],
    tags: ['Discipline', 'Profitable'],
    screenshots: []
  },
  {
    id: '2',
    date: '2024-01-14',
    title: 'Mixed Results - Learning Experience',
    mood: 'neutral',
    content: 'Started the day well but got emotional after a loss. Need to work on emotional control and stick to the plan regardless of recent results.',
    mistakes: ['Moved stop loss', 'Overtraded after loss'],
    wins: ['Good initial analysis', 'Journaled everything'],
    lessons: ['Never move stop loss', 'Take breaks after losses'],
    tags: ['Emotional', 'Learning'],
    screenshots: []
  },
  {
    id: '3',
    date: '2024-01-13',
    title: 'Tough Day - FOMO Trading',
    mood: 'bad',
    content: 'Fell into FOMO trading after missing a good setup. Took low-quality trades trying to make up for missed opportunity. This is a recurring pattern I need to address.',
    mistakes: ['FOMO trading', 'Ignored trading rules', 'No patience'],
    wins: ['Stopped trading early'],
    lessons: ['Missing trades is part of trading', 'Stick to A+ setups only'],
    tags: ['FOMO', 'Loss'],
    screenshots: []
  },
]

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']

const moodIcons = {
  great: { icon: Smile, color: 'text-[var(--profit)]', bg: 'bg-[var(--profit)]/15' },
  good: { icon: Smile, color: 'text-[var(--profit)]/80', bg: 'bg-[var(--profit)]/10' },
  neutral: { icon: Meh, color: 'text-[var(--warning)]', bg: 'bg-[var(--warning)]/15' },
  bad: { icon: Frown, color: 'text-[var(--loss)]/80', bg: 'bg-[var(--loss)]/10' },
  terrible: { icon: Frown, color: 'text-[var(--loss)]', bg: 'bg-[var(--loss)]/15' },
}

export default function JournalPage() {
  const [entries, setEntries] = useState(mockEntries)
  const [searchQuery, setSearchQuery] = useState('')
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedEntry, setSelectedEntry] = useState<JournalEntry | null>(null)
  const [showNewEntry, setShowNewEntry] = useState(false)
  const [viewMode, setViewMode] = useState<'calendar' | 'list'>('list')

  const year = currentDate.getFullYear()
  const month = currentDate.getMonth()

  const prevMonth = () => setCurrentDate(new Date(year, month - 1, 1))
  const nextMonth = () => setCurrentDate(new Date(year, month + 1, 1))

  const filteredEntries = entries.filter(entry =>
    entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    entry.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
    entry.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  const getEntryForDate = (dateStr: string) => entries.find(e => e.date === dateStr)

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Trading Journal</h1>
          <p className="text-muted-foreground mt-1">Document your trading journey and learn from every trade</p>
        </div>
        <div className="flex gap-3">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary text-secondary-foreground font-medium text-sm hover:bg-secondary/80 transition-colors"
          >
            <Sparkles className="h-4 w-4" />
            AI Summary
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowNewEntry(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-colors"
          >
            <Plus className="h-4 w-4" />
            New Entry
          </motion.button>
        </div>
      </motion.div>

      {/* Search & View Toggle */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search journal entries..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-card border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
          />
        </div>
        <div className="flex gap-1 bg-card border border-border p-1 rounded-xl">
          <button
            onClick={() => setViewMode('list')}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-medium transition-all",
              viewMode === 'list' ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
            )}
          >
            List
          </button>
          <button
            onClick={() => setViewMode('calendar')}
            className={cn(
              "px-4 py-2 rounded-lg text-sm font-medium transition-all",
              viewMode === 'calendar' ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
            )}
          >
            Calendar
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Journal Entries List */}
        <div className="lg:col-span-2 space-y-4">
          {viewMode === 'list' ? (
            filteredEntries.map((entry, index) => {
              const MoodIcon = moodIcons[entry.mood].icon
              return (
                <motion.div
                  key={entry.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => setSelectedEntry(entry)}
                  className={cn(
                    "p-5 rounded-2xl bg-card border border-border cursor-pointer transition-all hover:border-primary/30",
                    selectedEntry?.id === entry.id && "border-primary/50 ring-1 ring-primary/20"
                  )}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">
                        {new Date(entry.date).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}
                      </p>
                      <h3 className="font-semibold text-lg">{entry.title}</h3>
                    </div>
                    <div className={cn("p-2 rounded-xl", moodIcons[entry.mood].bg)}>
                      <MoodIcon className={cn("h-5 w-5", moodIcons[entry.mood].color)} />
                    </div>
                  </div>
                  
                  <p className="text-muted-foreground text-sm line-clamp-2 mb-4">{entry.content}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {entry.tags.map((tag) => (
                      <span key={tag} className="px-2 py-1 rounded-lg bg-muted text-xs font-medium">
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Quick Stats */}
                  <div className="flex gap-4 mt-4 pt-4 border-t border-border">
                    {entry.mistakes.length > 0 && (
                      <div className="flex items-center gap-1.5 text-sm text-[var(--loss)]">
                        <AlertTriangle className="h-4 w-4" />
                        {entry.mistakes.length} mistakes
                      </div>
                    )}
                    {entry.wins.length > 0 && (
                      <div className="flex items-center gap-1.5 text-sm text-[var(--profit)]">
                        <CheckCircle2 className="h-4 w-4" />
                        {entry.wins.length} wins
                      </div>
                    )}
                    {entry.lessons.length > 0 && (
                      <div className="flex items-center gap-1.5 text-sm text-primary">
                        <Lightbulb className="h-4 w-4" />
                        {entry.lessons.length} lessons
                      </div>
                    )}
                  </div>
                </motion.div>
              )
            })
          ) : (
            <GlassCard>
              {/* Calendar Header */}
              <div className="flex items-center justify-between p-5 border-b border-border">
                <button onClick={prevMonth} className="p-2 rounded-lg hover:bg-muted transition-colors">
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <h3 className="font-semibold text-lg">{MONTHS[month]} {year}</h3>
                <button onClick={nextMonth} className="p-2 rounded-lg hover:bg-muted transition-colors">
                  <ChevronRight className="h-5 w-5" />
                </button>
              </div>

              {/* Calendar Grid */}
              <div className="p-5">
                <div className="grid grid-cols-7 gap-2 mb-2">
                  {DAYS.map((day) => (
                    <div key={day} className="text-center text-xs text-muted-foreground font-medium py-2">
                      {day}
                    </div>
                  ))}
                </div>
                <div className="grid grid-cols-7 gap-2">
                  {Array.from({ length: new Date(year, month, 1).getDay() }).map((_, i) => (
                    <div key={`empty-${i}`} className="aspect-square" />
                  ))}
                  {Array.from({ length: new Date(year, month + 1, 0).getDate() }).map((_, i) => {
                    const day = i + 1
                    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`
                    const entry = getEntryForDate(dateStr)
                    const isToday = new Date().toDateString() === new Date(year, month, day).toDateString()
                    
                    return (
                      <motion.button
                        key={day}
                        whileHover={{ scale: 1.1 }}
                        onClick={() => entry && setSelectedEntry(entry)}
                        className={cn(
                          "aspect-square rounded-xl flex flex-col items-center justify-center text-sm transition-all relative",
                          entry && moodIcons[entry.mood].bg,
                          entry && "cursor-pointer hover:ring-2 hover:ring-primary/30",
                          !entry && "hover:bg-muted/50",
                          isToday && "ring-2 ring-primary"
                        )}
                      >
                        <span className={cn(
                          "font-medium",
                          entry ? moodIcons[entry.mood].color : "text-muted-foreground"
                        )}>
                          {day}
                        </span>
                      </motion.button>
                    )
                  })}
                </div>
              </div>
            </GlassCard>
          )}
        </div>

        {/* Selected Entry Detail / Quick Stats */}
        <div className="space-y-4">
          {selectedEntry ? (
            <GlassCard delay={0.1}>
              <div className="p-5 border-b border-border">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm text-muted-foreground">
                    {new Date(selectedEntry.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </p>
                  <button onClick={() => setSelectedEntry(null)} className="p-1 rounded hover:bg-muted">
                    <X className="h-4 w-4" />
                  </button>
                </div>
                <h3 className="font-semibold">{selectedEntry.title}</h3>
              </div>
              
              <div className="p-5 space-y-4 max-h-[60vh] overflow-y-auto">
                <p className="text-sm text-muted-foreground">{selectedEntry.content}</p>

                {selectedEntry.mistakes.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium flex items-center gap-2 mb-2 text-[var(--loss)]">
                      <AlertTriangle className="h-4 w-4" /> Mistakes
                    </h4>
                    <ul className="space-y-1">
                      {selectedEntry.mistakes.map((mistake, i) => (
                        <li key={i} className="text-sm text-muted-foreground pl-4 relative before:absolute before:left-0 before:top-2 before:w-1.5 before:h-1.5 before:rounded-full before:bg-[var(--loss)]">
                          {mistake}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {selectedEntry.wins.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium flex items-center gap-2 mb-2 text-[var(--profit)]">
                      <CheckCircle2 className="h-4 w-4" /> What Went Well
                    </h4>
                    <ul className="space-y-1">
                      {selectedEntry.wins.map((win, i) => (
                        <li key={i} className="text-sm text-muted-foreground pl-4 relative before:absolute before:left-0 before:top-2 before:w-1.5 before:h-1.5 before:rounded-full before:bg-[var(--profit)]">
                          {win}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {selectedEntry.lessons.length > 0 && (
                  <div>
                    <h4 className="text-sm font-medium flex items-center gap-2 mb-2 text-primary">
                      <Lightbulb className="h-4 w-4" /> Lessons Learned
                    </h4>
                    <ul className="space-y-1">
                      {selectedEntry.lessons.map((lesson, i) => (
                        <li key={i} className="text-sm text-muted-foreground pl-4 relative before:absolute before:left-0 before:top-2 before:w-1.5 before:h-1.5 before:rounded-full before:bg-primary">
                          {lesson}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </GlassCard>
          ) : (
            <GlassCard delay={0.1}>
              <div className="p-5 border-b border-border">
                <h3 className="font-semibold">Journal Stats</h3>
              </div>
              <div className="p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Total Entries</span>
                  <span className="font-semibold">{entries.length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">This Month</span>
                  <span className="font-semibold">
                    {entries.filter(e => new Date(e.date).getMonth() === month).length}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Avg Mood</span>
                  <div className="flex items-center gap-2">
                    <Smile className="h-4 w-4 text-[var(--profit)]" />
                    <span className="font-semibold">Good</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Lessons Learned</span>
                  <span className="font-semibold">{entries.reduce((acc, e) => acc + e.lessons.length, 0)}</span>
                </div>
              </div>
            </GlassCard>
          )}

          {/* AI Insights */}
          <GlassCard delay={0.2}>
            <div className="p-5 border-b border-border">
              <h3 className="font-semibold flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-primary" />
                AI Insights
              </h3>
            </div>
            <div className="p-5 space-y-3">
              <div className="p-3 rounded-xl bg-primary/5 border border-primary/20">
                <p className="text-sm"><span className="font-medium text-primary">Pattern Detected:</span> You tend to overtrade after losses. Consider implementing a cooldown rule.</p>
              </div>
              <div className="p-3 rounded-xl bg-[var(--profit)]/5 border border-[var(--profit)]/20">
                <p className="text-sm"><span className="font-medium text-[var(--profit)]">Strength:</span> Your win rate improves significantly when you trade during London session.</p>
              </div>
              <div className="p-3 rounded-xl bg-[var(--warning)]/5 border border-[var(--warning)]/20">
                <p className="text-sm"><span className="font-medium text-[var(--warning)]">Suggestion:</span> Review your breakout strategy - it has the highest success rate.</p>
              </div>
            </div>
          </GlassCard>
        </div>
      </div>

      {/* New Entry Modal */}
      <AnimatePresence>
        {showNewEntry && (
          <NewEntryModal onClose={() => setShowNewEntry(false)} />
        )}
      </AnimatePresence>
    </div>
  )
}

function NewEntryModal({ onClose }: { onClose: () => void }) {
  const [mood, setMood] = useState<'great' | 'good' | 'neutral' | 'bad' | 'terrible'>('neutral')

  const moods = [
    { value: 'great', icon: Smile, label: 'Great' },
    { value: 'good', icon: Smile, label: 'Good' },
    { value: 'neutral', icon: Meh, label: 'Neutral' },
    { value: 'bad', icon: Frown, label: 'Bad' },
    { value: 'terrible', icon: Frown, label: 'Terrible' },
  ] as const

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-card border border-border rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden"
      >
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="text-lg font-semibold">New Journal Entry</h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-muted transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto max-h-[60vh] space-y-5">
          {/* Date & Title */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Date</label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  type="date"
                  defaultValue={new Date().toISOString().split('T')[0]}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Title</label>
              <input
                type="text"
                placeholder="How was your trading day?"
                className="w-full px-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
            </div>
          </div>

          {/* Mood Selector */}
          <div>
            <label className="block text-sm font-medium mb-2">How are you feeling?</label>
            <div className="flex gap-2">
              {moods.map((m) => (
                <button
                  key={m.value}
                  onClick={() => setMood(m.value)}
                  className={cn(
                    "flex-1 flex flex-col items-center gap-1 p-3 rounded-xl border transition-all",
                    mood === m.value
                      ? cn(moodIcons[m.value].bg, "border-current", moodIcons[m.value].color)
                      : "border-border hover:bg-muted"
                  )}
                >
                  <m.icon className={cn("h-5 w-5", mood === m.value ? moodIcons[m.value].color : "text-muted-foreground")} />
                  <span className="text-xs">{m.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Rich Text Editor */}
          <div>
            <label className="block text-sm font-medium mb-2">Daily Notes</label>
            <div className="border border-border rounded-xl overflow-hidden">
              {/* Toolbar */}
              <div className="flex gap-1 p-2 border-b border-border bg-muted/30">
                <button className="p-2 rounded hover:bg-muted transition-colors">
                  <Bold className="h-4 w-4" />
                </button>
                <button className="p-2 rounded hover:bg-muted transition-colors">
                  <Italic className="h-4 w-4" />
                </button>
                <button className="p-2 rounded hover:bg-muted transition-colors">
                  <List className="h-4 w-4" />
                </button>
                <button className="p-2 rounded hover:bg-muted transition-colors">
                  <ListOrdered className="h-4 w-4" />
                </button>
                <button className="p-2 rounded hover:bg-muted transition-colors">
                  <Quote className="h-4 w-4" />
                </button>
              </div>
              <textarea
                rows={4}
                placeholder="Write about your trading day, thoughts, emotions..."
                className="w-full px-4 py-3 bg-transparent text-sm focus:outline-none resize-none"
              />
            </div>
          </div>

          {/* Mistakes, Wins, Lessons */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2 flex items-center gap-2 text-[var(--loss)]">
                <AlertTriangle className="h-4 w-4" /> Mistakes
              </label>
              <textarea
                rows={3}
                placeholder="What went wrong?"
                className="w-full px-4 py-2.5 rounded-xl bg-[var(--loss)]/5 border border-[var(--loss)]/20 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--loss)]/30 resize-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 flex items-center gap-2 text-[var(--profit)]">
                <CheckCircle2 className="h-4 w-4" /> What Went Well
              </label>
              <textarea
                rows={3}
                placeholder="Celebrate your wins!"
                className="w-full px-4 py-2.5 rounded-xl bg-[var(--profit)]/5 border border-[var(--profit)]/20 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--profit)]/30 resize-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2 flex items-center gap-2 text-primary">
                <Lightbulb className="h-4 w-4" /> Lessons Learned
              </label>
              <textarea
                rows={3}
                placeholder="Key takeaways"
                className="w-full px-4 py-2.5 rounded-xl bg-primary/5 border border-primary/20 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 resize-none"
              />
            </div>
          </div>

          {/* Tags */}
          <div>
            <label className="block text-sm font-medium mb-2 flex items-center gap-2">
              <Tag className="h-4 w-4" /> Tags
            </label>
            <input
              type="text"
              placeholder="Add tags separated by commas"
              className="w-full px-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>

          {/* Screenshot Upload */}
          <div>
            <label className="block text-sm font-medium mb-2 flex items-center gap-2">
              <Image className="h-4 w-4" /> Screenshots
            </label>
            <div className="border-2 border-dashed border-border rounded-xl p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
              <Image className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">Click to upload chart screenshots</p>
            </div>
          </div>
        </div>

        <div className="flex gap-3 p-5 border-t border-border">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl bg-muted text-sm font-medium hover:bg-muted/80 transition-colors">
            Cancel
          </button>
          <button className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
            <Brain className="h-4 w-4" />
            Save Entry
          </button>
        </div>
      </motion.div>
    </motion.div>
  )
}
