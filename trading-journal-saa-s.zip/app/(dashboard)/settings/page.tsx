'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import { Settings, User, Bell, Shield, Palette, Database, CreditCard, HelpCircle, LogOut, ChevronRight, Moon, Sun, Check } from 'lucide-react'
import { cn } from '@/lib/utils'
import { GlassCard, CardHeader } from '@/components/ui/stats-card'

const settingsSections = [
  {
    title: 'Account',
    items: [
      { icon: User, label: 'Profile Settings', description: 'Manage your account details' },
      { icon: Bell, label: 'Notifications', description: 'Configure alerts and notifications' },
      { icon: Shield, label: 'Security', description: 'Password and two-factor authentication' },
    ]
  },
  {
    title: 'Preferences',
    items: [
      { icon: Palette, label: 'Appearance', description: 'Theme, colors, and display options' },
      { icon: Database, label: 'Data & Sync', description: 'Backup and sync settings' },
    ]
  },
  {
    title: 'Subscription',
    items: [
      { icon: CreditCard, label: 'Billing', description: 'Manage your subscription' },
    ]
  },
]

export default function SettingsPage() {
  const [theme, setTheme] = useState<'dark' | 'light'>('dark')

  return (
    <div className="p-4 lg:p-8 space-y-6 max-w-4xl">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-2xl lg:text-3xl font-bold">Settings</h1>
        <p className="text-muted-foreground mt-1">Manage your account and preferences</p>
      </motion.div>

      {/* Settings Sections */}
      {settingsSections.map((section, sectionIndex) => (
        <GlassCard key={section.title} delay={sectionIndex * 0.1}>
          <div className="p-5 border-b border-border">
            <h3 className="font-semibold">{section.title}</h3>
          </div>
          <div className="divide-y divide-border">
            {section.items.map((item, index) => (
              <motion.button
                key={item.label}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: sectionIndex * 0.1 + index * 0.05 }}
                className="w-full flex items-center gap-4 p-5 hover:bg-muted/30 transition-colors text-left"
              >
                <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <item.icon className="h-5 w-5 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="font-medium">{item.label}</p>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </motion.button>
            ))}
          </div>
        </GlassCard>
      ))}

      {/* Theme Toggle */}
      <GlassCard delay={0.3}>
        <div className="p-5 border-b border-border">
          <h3 className="font-semibold">Theme</h3>
        </div>
        <div className="p-5">
          <div className="flex gap-3">
            <button
              onClick={() => setTheme('dark')}
              className={cn(
                "flex-1 flex items-center gap-3 p-4 rounded-xl border transition-all",
                theme === 'dark' ? "border-primary bg-primary/10" : "border-border hover:bg-muted/30"
              )}
            >
              <Moon className="h-5 w-5" />
              <span className="font-medium">Dark</span>
              {theme === 'dark' && <Check className="h-4 w-4 text-primary ml-auto" />}
            </button>
            <button
              onClick={() => setTheme('light')}
              className={cn(
                "flex-1 flex items-center gap-3 p-4 rounded-xl border transition-all",
                theme === 'light' ? "border-primary bg-primary/10" : "border-border hover:bg-muted/30"
              )}
            >
              <Sun className="h-5 w-5" />
              <span className="font-medium">Light</span>
              {theme === 'light' && <Check className="h-4 w-4 text-primary ml-auto" />}
            </button>
          </div>
        </div>
      </GlassCard>

      {/* Help & Logout */}
      <GlassCard delay={0.4}>
        <div className="divide-y divide-border">
          <button className="w-full flex items-center gap-4 p-5 hover:bg-muted/30 transition-colors text-left">
            <div className="h-10 w-10 rounded-xl bg-muted flex items-center justify-center">
              <HelpCircle className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <p className="font-medium">Help & Support</p>
              <p className="text-sm text-muted-foreground">Get help with EdgeSync</p>
            </div>
            <ChevronRight className="h-5 w-5 text-muted-foreground" />
          </button>
          <button className="w-full flex items-center gap-4 p-5 hover:bg-destructive/10 transition-colors text-left text-destructive">
            <div className="h-10 w-10 rounded-xl bg-destructive/10 flex items-center justify-center">
              <LogOut className="h-5 w-5" />
            </div>
            <div className="flex-1">
              <p className="font-medium">Sign Out</p>
              <p className="text-sm opacity-70">Log out of your account</p>
            </div>
          </button>
        </div>
      </GlassCard>
    </div>
  )
}
