'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  Calendar,
  TrendingUp,
  TrendingDown,
  Target,
  Activity,
  Clock,
  Zap,
  Award,
  AlertTriangle,
  BarChart3,
  Filter,
  Download,
  ChevronDown,
  Check,
  Sparkles,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { GlassCard, CardHeader } from '@/components/ui/stats-card'
import { AnimatePresence } from 'framer-motion'

interface StatItem {
  label: string
  value: string | number
  subValue?: string
  icon: React.ElementType
  type: 'positive' | 'negative' | 'neutral'
}

const overviewStats: StatItem[] = [
  { label: 'Total Trading Days', value: 124, subValue: 'Since Jan 2024', icon: Calendar, type: 'neutral' },
  { label: 'Total Winning Days', value: 84, subValue: '67.7%', icon: TrendingUp, type: 'positive' },
  { label: 'Total Losing Days', value: 40, subValue: '32.3%', icon: TrendingDown, type: 'negative' },
  { label: 'Avg Trades/Day', value: '2.3', subValue: '284 total', icon: Activity, type: 'neutral' },
]

const performanceStats: StatItem[] = [
  { label: 'Largest Win', value: '$892.50', subValue: 'XAU/USD', icon: Award, type: 'positive' },
  { label: 'Largest Loss', value: '-$456.20', subValue: 'GBP/JPY', icon: AlertTriangle, type: 'negative' },
  { label: 'Sharpe Ratio', value: '1.87', subValue: 'Excellent', icon: Target, type: 'positive' },
  { label: 'Max Drawdown', value: '-12.4%', subValue: '$2,480', icon: TrendingDown, type: 'negative' },
]

const advancedStats: StatItem[] = [
  { label: 'Recovery Factor', value: '3.2', subValue: 'Strong', icon: Zap, type: 'positive' },
  { label: 'Avg Hold Time', value: '2h 34m', subValue: 'Intraday', icon: Clock, type: 'neutral' },
  { label: 'Trading Frequency', value: '5.2/week', subValue: 'Moderate', icon: BarChart3, type: 'neutral' },
  { label: 'Consecutive Wins', value: 12, subValue: 'Max streak', icon: Award, type: 'positive' },
  { label: 'Consecutive Losses', value: 4, subValue: 'Max streak', icon: AlertTriangle, type: 'negative' },
  { label: 'Breakeven Trades', value: 8, subValue: '2.8%', icon: Activity, type: 'neutral' },
]

const sessionStats = [
  { session: 'Asian', trades: 45, winRate: 62.2, pnl: 890, avgRR: 1.4, avgHoldTime: '1h 45m', bestPair: 'USD/JPY' },
  { session: 'London', trades: 85, winRate: 71.8, pnl: 2340, avgRR: 1.8, avgHoldTime: '2h 12m', bestPair: 'EUR/USD' },
  { session: 'New York', trades: 72, winRate: 68.1, pnl: 1580, avgRR: 1.6, avgHoldTime: '2h 45m', bestPair: 'XAU/USD' },
]

const strategyStats = [
  { strategy: 'Breakout', trades: 95, winRate: 72.6, pnl: 2180, avgRR: 1.9, profitFactor: 2.4 },
  { strategy: 'Reversal', trades: 68, winRate: 64.7, pnl: 890, avgRR: 1.5, profitFactor: 1.8 },
  { strategy: 'Trend', trades: 82, winRate: 69.5, pnl: 1540, avgRR: 1.7, profitFactor: 2.1 },
  { strategy: 'Scalp', trades: 39, winRate: 58.9, pnl: 200, avgRR: 1.1, profitFactor: 1.3 },
]

const pairStats = [
  { pair: 'EUR/USD', trades: 52, winRate: 73.1, pnl: 1240, avgRR: 1.9, sessions: 'London, NY' },
  { pair: 'GBP/JPY', trades: 38, winRate: 65.8, pnl: 680, avgRR: 1.6, sessions: 'London' },
  { pair: 'XAU/USD', trades: 45, winRate: 68.9, pnl: 980, avgRR: 1.7, sessions: 'NY' },
  { pair: 'BTC/USD', trades: 28, winRate: 60.7, pnl: 420, avgRR: 1.4, sessions: 'Asian, NY' },
  { pair: 'USD/JPY', trades: 35, winRate: 71.4, pnl: 890, avgRR: 1.8, sessions: 'Asian' },
  { pair: 'NAS100', trades: 42, winRate: 66.7, pnl: 760, avgRR: 1.5, sessions: 'NY' },
]

const timeFilters = ['All Time', 'This Year', 'This Month', 'This Week', 'Custom']
const pairFilters = ['All Pairs', 'Forex', 'Crypto', 'Indices', 'Commodities']

export default function StatisticsPage() {
  const [timeFilter, setTimeFilter] = useState('All Time')
  const [pairFilter, setPairFilter] = useState('All Pairs')
  const [showAIInsights, setShowAIInsights] = useState(false)

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Detailed Statistics</h1>
          <p className="text-muted-foreground mt-1">Comprehensive breakdown of your trading performance</p>
        </div>
        <div className="flex gap-3">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowAIInsights(!showAIInsights)}
            className={cn(
              "flex items-center gap-2 px-4 py-2.5 rounded-xl font-medium text-sm transition-colors",
              showAIInsights 
                ? "bg-primary text-primary-foreground" 
                : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
            )}
          >
            <Sparkles className="h-4 w-4" />
            AI Insights
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary text-secondary-foreground font-medium text-sm hover:bg-secondary/80 transition-colors"
          >
            <Download className="h-4 w-4" />
            Export PDF
          </motion.button>
        </div>
      </motion.div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <FilterDropdown label="Time Period" value={timeFilter} options={timeFilters} onChange={setTimeFilter} />
        <FilterDropdown label="Instrument" value={pairFilter} options={pairFilters} onChange={setPairFilter} />
      </div>

      {/* AI Insights Panel */}
      <AnimatePresence>
        {showAIInsights && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <GlassCard>
              <div className="p-5 border-b border-border flex items-center gap-3">
                <div className="p-2 rounded-xl bg-primary/15">
                  <Sparkles className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold">AI Performance Analysis</h3>
              </div>
              <div className="p-5 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className="p-4 rounded-xl bg-[var(--profit)]/5 border border-[var(--profit)]/20">
                  <h4 className="font-medium text-[var(--profit)] mb-2">Strengths</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-[var(--profit)] mt-0.5 shrink-0" />
                      Excellent win rate on EUR/USD (73.1%)
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-[var(--profit)] mt-0.5 shrink-0" />
                      Breakout strategy is most profitable
                    </li>
                    <li className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-[var(--profit)] mt-0.5 shrink-0" />
                      London session performance is outstanding
                    </li>
                  </ul>
                </div>
                <div className="p-4 rounded-xl bg-[var(--loss)]/5 border border-[var(--loss)]/20">
                  <h4 className="font-medium text-[var(--loss)] mb-2">Areas to Improve</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <AlertTriangle className="h-4 w-4 text-[var(--loss)] mt-0.5 shrink-0" />
                      Scalp strategy needs review (58.9% WR)
                    </li>
                    <li className="flex items-start gap-2">
                      <AlertTriangle className="h-4 w-4 text-[var(--loss)] mt-0.5 shrink-0" />
                      BTC/USD trades underperforming
                    </li>
                    <li className="flex items-start gap-2">
                      <AlertTriangle className="h-4 w-4 text-[var(--loss)] mt-0.5 shrink-0" />
                      Consider reducing Asian session trades
                    </li>
                  </ul>
                </div>
                <div className="p-4 rounded-xl bg-primary/5 border border-primary/20">
                  <h4 className="font-medium text-primary mb-2">Recommendations</h4>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li className="flex items-start gap-2">
                      <Sparkles className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                      Focus more on London session breakouts
                    </li>
                    <li className="flex items-start gap-2">
                      <Sparkles className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                      Increase position size on EUR/USD setups
                    </li>
                    <li className="flex items-start gap-2">
                      <Sparkles className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                      Set a max loss rule of $500/day
                    </li>
                  </ul>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Overview Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {overviewStats.map((stat, index) => (
          <StatCard key={stat.label} stat={stat} delay={index * 0.05} />
        ))}
      </div>

      {/* Performance Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {performanceStats.map((stat, index) => (
          <StatCard key={stat.label} stat={stat} delay={0.2 + index * 0.05} />
        ))}
      </div>

      {/* Advanced Stats */}
      <GlassCard delay={0.4}>
        <CardHeader title="Advanced Metrics" />
        <div className="p-5 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {advancedStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + index * 0.05 }}
              className="p-4 rounded-xl bg-muted/30"
            >
              <div className={cn(
                "h-8 w-8 rounded-lg flex items-center justify-center mb-3",
                stat.type === 'positive' && "bg-[var(--profit)]/15 text-[var(--profit)]",
                stat.type === 'negative' && "bg-[var(--loss)]/15 text-[var(--loss)]",
                stat.type === 'neutral' && "bg-primary/15 text-primary"
              )}>
                <stat.icon className="h-4 w-4" />
              </div>
              <p className="text-xs text-muted-foreground mb-1">{stat.label}</p>
              <p className="text-lg font-bold">{stat.value}</p>
              {stat.subValue && (
                <p className="text-xs text-muted-foreground">{stat.subValue}</p>
              )}
            </motion.div>
          ))}
        </div>
      </GlassCard>

      {/* Session & Strategy Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Session Statistics */}
        <GlassCard delay={0.5}>
          <CardHeader title="Session Statistics" />
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="px-5 py-3 font-medium">Session</th>
                  <th className="px-5 py-3 font-medium">Trades</th>
                  <th className="px-5 py-3 font-medium">Win Rate</th>
                  <th className="px-5 py-3 font-medium">P&L</th>
                  <th className="px-5 py-3 font-medium hidden sm:table-cell">Avg RR</th>
                </tr>
              </thead>
              <tbody>
                {sessionStats.map((session, index) => (
                  <motion.tr
                    key={session.session}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.5 + index * 0.05 }}
                    className="border-b border-border/50"
                  >
                    <td className="px-5 py-4 font-medium">{session.session}</td>
                    <td className="px-5 py-4 text-muted-foreground">{session.trades}</td>
                    <td className="px-5 py-4">
                      <span className={cn(
                        "px-2 py-1 rounded-md text-xs font-medium",
                        session.winRate >= 70 ? "bg-[var(--profit)]/15 text-[var(--profit)]" :
                        session.winRate >= 60 ? "bg-[var(--warning)]/15 text-[var(--warning)]" :
                        "bg-[var(--loss)]/15 text-[var(--loss)]"
                      )}>
                        {session.winRate}%
                      </span>
                    </td>
                    <td className={cn(
                      "px-5 py-4 font-semibold",
                      session.pnl >= 0 ? "text-[var(--profit)]" : "text-[var(--loss)]"
                    )}>
                      {session.pnl >= 0 ? '+' : ''}${session.pnl}
                    </td>
                    <td className="px-5 py-4 text-muted-foreground hidden sm:table-cell">{session.avgRR}R</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>

        {/* Strategy Statistics */}
        <GlassCard delay={0.55}>
          <CardHeader title="Strategy Statistics" />
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left text-xs text-muted-foreground border-b border-border">
                  <th className="px-5 py-3 font-medium">Strategy</th>
                  <th className="px-5 py-3 font-medium">Trades</th>
                  <th className="px-5 py-3 font-medium">Win Rate</th>
                  <th className="px-5 py-3 font-medium">P&L</th>
                  <th className="px-5 py-3 font-medium hidden sm:table-cell">PF</th>
                </tr>
              </thead>
              <tbody>
                {strategyStats.map((strategy, index) => (
                  <motion.tr
                    key={strategy.strategy}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.55 + index * 0.05 }}
                    className="border-b border-border/50"
                  >
                    <td className="px-5 py-4 font-medium">{strategy.strategy}</td>
                    <td className="px-5 py-4 text-muted-foreground">{strategy.trades}</td>
                    <td className="px-5 py-4">
                      <span className={cn(
                        "px-2 py-1 rounded-md text-xs font-medium",
                        strategy.winRate >= 70 ? "bg-[var(--profit)]/15 text-[var(--profit)]" :
                        strategy.winRate >= 60 ? "bg-[var(--warning)]/15 text-[var(--warning)]" :
                        "bg-[var(--loss)]/15 text-[var(--loss)]"
                      )}>
                        {strategy.winRate}%
                      </span>
                    </td>
                    <td className={cn(
                      "px-5 py-4 font-semibold",
                      strategy.pnl >= 0 ? "text-[var(--profit)]" : "text-[var(--loss)]"
                    )}>
                      {strategy.pnl >= 0 ? '+' : ''}${strategy.pnl}
                    </td>
                    <td className="px-5 py-4 text-muted-foreground hidden sm:table-cell">{strategy.profitFactor}</td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </GlassCard>
      </div>

      {/* Pair Statistics */}
      <GlassCard delay={0.6}>
        <CardHeader title="Instrument Statistics" />
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-xs text-muted-foreground border-b border-border">
                <th className="px-5 py-3 font-medium">Pair</th>
                <th className="px-5 py-3 font-medium">Trades</th>
                <th className="px-5 py-3 font-medium">Win Rate</th>
                <th className="px-5 py-3 font-medium">Total P&L</th>
                <th className="px-5 py-3 font-medium hidden md:table-cell">Avg RR</th>
                <th className="px-5 py-3 font-medium hidden lg:table-cell">Best Sessions</th>
              </tr>
            </thead>
            <tbody>
              {pairStats.map((pair, index) => (
                <motion.tr
                  key={pair.pair}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.6 + index * 0.03 }}
                  className="border-b border-border/50 hover:bg-muted/30 transition-colors"
                >
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-2">
                      <div className={cn(
                        "h-8 w-8 rounded-lg flex items-center justify-center text-xs font-bold",
                        pair.pnl >= 0 ? "bg-[var(--profit)]/15 text-[var(--profit)]" : "bg-[var(--loss)]/15 text-[var(--loss)]"
                      )}>
                        {pair.pair.slice(0, 2)}
                      </div>
                      <span className="font-medium">{pair.pair}</span>
                    </div>
                  </td>
                  <td className="px-5 py-4 text-muted-foreground">{pair.trades}</td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-2">
                      <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className={cn(
                            "h-full rounded-full",
                            pair.winRate >= 70 ? "bg-[var(--profit)]" :
                            pair.winRate >= 60 ? "bg-[var(--warning)]" :
                            "bg-[var(--loss)]"
                          )}
                          style={{ width: `${pair.winRate}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium">{pair.winRate}%</span>
                    </div>
                  </td>
                  <td className={cn(
                    "px-5 py-4 font-semibold",
                    pair.pnl >= 0 ? "text-[var(--profit)]" : "text-[var(--loss)]"
                  )}>
                    {pair.pnl >= 0 ? '+' : ''}${pair.pnl}
                  </td>
                  <td className="px-5 py-4 text-muted-foreground hidden md:table-cell">{pair.avgRR}R</td>
                  <td className="px-5 py-4 hidden lg:table-cell">
                    <span className="px-2 py-1 rounded-md bg-muted text-xs">{pair.sessions}</span>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </GlassCard>
    </div>
  )
}

function StatCard({ stat, delay }: { stat: StatItem; delay: number }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay }}
      className="p-5 rounded-2xl bg-card border border-border"
    >
      <div className={cn(
        "h-10 w-10 rounded-xl flex items-center justify-center mb-3",
        stat.type === 'positive' && "bg-[var(--profit)]/15 text-[var(--profit)]",
        stat.type === 'negative' && "bg-[var(--loss)]/15 text-[var(--loss)]",
        stat.type === 'neutral' && "bg-primary/15 text-primary"
      )}>
        <stat.icon className="h-5 w-5" />
      </div>
      <p className="text-sm text-muted-foreground mb-1">{stat.label}</p>
      <p className="text-2xl font-bold">{stat.value}</p>
      {stat.subValue && (
        <p className="text-xs text-muted-foreground mt-1">{stat.subValue}</p>
      )}
    </motion.div>
  )
}

function FilterDropdown({ 
  label,
  value, 
  options, 
  onChange 
}: { 
  label: string
  value: string
  options: string[]
  onChange: (value: string) => void 
}) {
  const [open, setOpen] = useState(false)

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-card border border-border text-sm hover:bg-muted transition-colors min-w-[160px]"
      >
        <Filter className="h-4 w-4 text-muted-foreground" />
        <span className="flex-1 text-left">
          <span className="text-muted-foreground">{label}:</span> {value}
        </span>
        <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} />
      </button>
      
      <AnimatePresence>
        {open && (
          <>
            <div className="fixed inset-0 z-10" onClick={() => setOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute top-full left-0 mt-2 w-full bg-card border border-border rounded-xl shadow-xl z-20 overflow-hidden"
            >
              {options.map((option) => (
                <button
                  key={option}
                  onClick={() => {
                    onChange(option)
                    setOpen(false)
                  }}
                  className={cn(
                    "w-full px-4 py-2.5 text-left text-sm hover:bg-muted transition-colors flex items-center justify-between",
                    value === option && "bg-primary/10 text-primary"
                  )}
                >
                  {option}
                  {value === option && <Check className="h-4 w-4" />}
                </button>
              ))}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}
