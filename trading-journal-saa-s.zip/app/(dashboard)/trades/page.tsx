'use client'

import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Upload,
  Plus,
  Search,
  Filter,
  Download,
  Trash2,
  Edit3,
  ArrowUpRight,
  ArrowDownRight,
  FileSpreadsheet,
  FileText,
  Image,
  Calendar,
  X,
  Check,
  ChevronDown
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { GlassCard } from '@/components/ui/stats-card'

interface Trade {
  id: string
  symbol: string
  type: 'BUY' | 'SELL'
  entry: number
  exit: number
  stopLoss: number
  takeProfit: number
  lotSize: number
  pnl: number
  rr: number
  session: string
  strategy: string
  date: string
  time: string
  notes: string
  screenshot?: string
}

const symbols = [
  'XAUUSD',
  'BTCUSD',
  'EUR/USD',
  'GBP/USD',
  'USD/JPY',
  'USD/CHF',
  'AUD/USD',
  'USD/CAD',
  'NZD/USD',
  'EUR/GBP',
  'EUR/JPY',
  'GBP/JPY',
  'EUR/CHF',
  'AUD/JPY',
  'CAD/JPY',
]

const mockTrades: Trade[] = [
  { id: '1', symbol: 'EUR/USD', type: 'BUY', entry: 1.0845, exit: 1.0892, stopLoss: 1.0820, takeProfit: 1.0920, lotSize: 1.0, pnl: 470, rr: 2.3, session: 'London', strategy: 'QML', date: '2024-01-15', time: '09:32', notes: 'Clean breakout from consolidation' },
  { id: '2', symbol: 'GBP/JPY', type: 'SELL', entry: 187.450, exit: 186.980, stopLoss: 187.800, takeProfit: 186.500, lotSize: 0.5, pnl: 235, rr: 1.8, session: 'London', strategy: 'TJL 2', date: '2024-01-15', time: '11:45', notes: 'Rejection at resistance' },
  { id: '3', symbol: 'XAUUSD', type: 'BUY', entry: 2024.50, exit: 2018.30, stopLoss: 2020.00, takeProfit: 2035.00, lotSize: 0.3, pnl: -186, rr: -0.9, session: 'New York', strategy: 'DT', date: '2024-01-14', time: '14:22', notes: 'Stopped out on news' },
  { id: '4', symbol: 'BTCUSD', type: 'SELL', entry: 42850, exit: 42340, stopLoss: 43100, takeProfit: 42000, lotSize: 0.1, pnl: 510, rr: 2.5, session: 'Asian', strategy: 'DB', date: '2024-01-14', time: '08:15', notes: 'Double top pattern' },
  { id: '5', symbol: 'USD/JPY', type: 'BUY', entry: 148.40, exit: 149.25, stopLoss: 147.80, takeProfit: 150.00, lotSize: 0.2, pnl: 170, rr: 1.4, session: 'New York', strategy: 'LVL 3', date: '2024-01-13', time: '15:30', notes: 'Momentum continuation' },
  { id: '6', symbol: 'EUR/GBP', type: 'SELL', entry: 0.8612, exit: 0.8645, stopLoss: 0.8580, takeProfit: 0.8550, lotSize: 1.5, pnl: -495, rr: -1.2, session: 'London', strategy: 'RBS', date: '2024-01-13', time: '10:08', notes: 'Failed breakdown' },
  { id: '7', symbol: 'USD/CAD', type: 'BUY', entry: 1.3420, exit: 1.3485, stopLoss: 1.3380, takeProfit: 1.3520, lotSize: 0.8, pnl: 520, rr: 1.9, session: 'New York', strategy: 'SBR', date: '2024-01-12', time: '13:45', notes: 'Clean trend continuation' },
  { id: '8', symbol: 'AUD/USD', type: 'SELL', entry: 0.6725, exit: 0.6680, stopLoss: 0.6750, takeProfit: 0.6650, lotSize: 1.2, pnl: 540, rr: 2.1, session: 'Asian', strategy: 'TJL 1', date: '2024-01-12', time: '03:20', notes: 'Bearish engulfing at resistance' },
]

const sessions = ['All Sessions', 'Asian', 'London', 'New York']
const strategies = ['All Strategies', 'QML', 'TJL 2', 'TJL 1', 'DT', 'DB', 'LVL 3', 'LVL 4', 'RBS', 'SBR']
const outcomes = ['All Trades', 'Winners', 'Losers']

export default function TradesPage() {
  const [trades, setTrades] = useState(mockTrades)
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedSession, setSelectedSession] = useState('All Sessions')
  const [selectedStrategy, setSelectedStrategy] = useState('All Strategies')
  const [selectedOutcome, setSelectedOutcome] = useState('All Trades')
  const [showImportModal, setShowImportModal] = useState(false)
  const [showAddModal, setShowAddModal] = useState(false)
  const [selectedTrades, setSelectedTrades] = useState<string[]>([])

  const filteredTrades = trades.filter(trade => {
    const matchesSearch = trade.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      trade.notes.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesSession = selectedSession === 'All Sessions' || trade.session === selectedSession
    const matchesStrategy = selectedStrategy === 'All Strategies' || trade.strategy === selectedStrategy
    const matchesOutcome = selectedOutcome === 'All Trades' ||
      (selectedOutcome === 'Winners' && trade.pnl >= 0) ||
      (selectedOutcome === 'Losers' && trade.pnl < 0)
    
    return matchesSearch && matchesSession && matchesStrategy && matchesOutcome
  })

  const toggleTradeSelection = (id: string) => {
    setSelectedTrades(prev => 
      prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]
    )
  }

  const selectAllTrades = () => {
    if (selectedTrades.length === filteredTrades.length) {
      setSelectedTrades([])
    } else {
      setSelectedTrades(filteredTrades.map(t => t.id))
    }
  }

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Trade Records</h1>
          <p className="text-muted-foreground mt-1">Manage and analyze all your trades</p>
        </div>
        <div className="flex gap-3">
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowImportModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary text-secondary-foreground font-medium text-sm hover:bg-secondary/80 transition-colors"
          >
            <Upload className="h-4 w-4" />
            Import
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-colors"
          >
            <Plus className="h-4 w-4" />
            Add Trade
          </motion.button>
        </div>
      </motion.div>

      {/* Filters */}
      <GlassCard delay={0.1} className="relative z-30 !overflow-visible">
        <div className="p-4 flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search trades..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
            />
          </div>

          {/* Filter Dropdowns */}
          <div className="flex flex-wrap gap-3">
            <FilterDropdown
              value={selectedSession}
              options={sessions}
              onChange={setSelectedSession}
            />
            <FilterDropdown
              value={selectedStrategy}
              options={strategies}
              onChange={setSelectedStrategy}
            />
            <FilterDropdown
              value={selectedOutcome}
              options={outcomes}
              onChange={setSelectedOutcome}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-2">
            <button className="p-2.5 rounded-xl bg-muted/50 border border-border hover:bg-muted transition-colors">
              <Download className="h-4 w-4" />
            </button>
            {selectedTrades.length > 0 && (
              <button className="p-2.5 rounded-xl bg-destructive/10 border border-destructive/20 text-destructive hover:bg-destructive/20 transition-colors">
                <Trash2 className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </GlassCard>

      {/* Trades Table */}
      <GlassCard delay={0.2}>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left text-xs text-muted-foreground border-b border-border">
                <th className="px-5 py-4">
                  <input
                    type="checkbox"
                    checked={selectedTrades.length === filteredTrades.length && filteredTrades.length > 0}
                    onChange={selectAllTrades}
                    className="rounded border-border"
                  />
                </th>
                <th className="px-5 py-4 font-medium">Symbol</th>
                <th className="px-5 py-4 font-medium">Type</th>
                <th className="px-5 py-4 font-medium hidden md:table-cell">Entry</th>
                <th className="px-5 py-4 font-medium hidden md:table-cell">Exit</th>
                <th className="px-5 py-4 font-medium hidden lg:table-cell">SL</th>
                <th className="px-5 py-4 font-medium hidden lg:table-cell">TP</th>
                <th className="px-5 py-4 font-medium hidden sm:table-cell">Lot</th>
                <th className="px-5 py-4 font-medium">P&L</th>
                <th className="px-5 py-4 font-medium hidden xl:table-cell">RR</th>
                <th className="px-5 py-4 font-medium hidden xl:table-cell">Session</th>
                <th className="px-5 py-4 font-medium hidden 2xl:table-cell">Strategy</th>
                <th className="px-5 py-4 font-medium hidden lg:table-cell">Date</th>
                <th className="px-5 py-4 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredTrades.map((trade, index) => (
                <motion.tr
                  key={trade.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.03 }}
                  className="border-b border-border/50 hover:bg-muted/30 transition-colors"
                >
                  <td className="px-5 py-4">
                    <input
                      type="checkbox"
                      checked={selectedTrades.includes(trade.id)}
                      onChange={() => toggleTradeSelection(trade.id)}
                      className="rounded border-border"
                    />
                  </td>
                  <td className="px-5 py-4">
                    <div className="flex items-center gap-2">
                      <div className={cn(
                        "h-8 w-8 rounded-lg flex items-center justify-center text-xs font-bold",
                        trade.pnl >= 0 
                          ? "bg-[var(--profit)]/15 text-[var(--profit)]" 
                          : "bg-[var(--loss)]/15 text-[var(--loss)]"
                      )}>
                        {trade.symbol.slice(0, 2)}
                      </div>
                      <span className="font-medium">{trade.symbol}</span>
                    </div>
                  </td>
                  <td className="px-5 py-4">
                    <span className={cn(
                      "inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium",
                      trade.type === 'BUY' 
                        ? "bg-[var(--profit)]/15 text-[var(--profit)]" 
                        : "bg-[var(--loss)]/15 text-[var(--loss)]"
                    )}>
                      {trade.type === 'BUY' ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                      {trade.type}
                    </span>
                  </td>
                  <td className="px-5 py-4 font-mono text-sm text-muted-foreground hidden md:table-cell">{trade.entry}</td>
                  <td className="px-5 py-4 font-mono text-sm text-muted-foreground hidden md:table-cell">{trade.exit}</td>
                  <td className="px-5 py-4 font-mono text-sm text-muted-foreground hidden lg:table-cell">{trade.stopLoss}</td>
                  <td className="px-5 py-4 font-mono text-sm text-muted-foreground hidden lg:table-cell">{trade.takeProfit}</td>
                  <td className="px-5 py-4 text-muted-foreground hidden sm:table-cell">{trade.lotSize}</td>
                  <td className={cn(
                    "px-5 py-4 font-semibold",
                    trade.pnl >= 0 ? "text-[var(--profit)]" : "text-[var(--loss)]"
                  )}>
                    {trade.pnl >= 0 ? '+' : ''}${trade.pnl.toFixed(2)}
                  </td>
                  <td className={cn(
                    "px-5 py-4 font-medium hidden xl:table-cell",
                    trade.rr >= 0 ? "text-[var(--profit)]" : "text-[var(--loss)]"
                  )}>
                    {trade.rr >= 0 ? '+' : ''}{trade.rr.toFixed(1)}R
                  </td>
                  <td className="px-5 py-4 text-muted-foreground hidden xl:table-cell">
                    <span className="px-2 py-1 rounded-md bg-muted text-xs">{trade.session}</span>
                  </td>
                  <td className="px-5 py-4 text-muted-foreground hidden 2xl:table-cell">
                    <span className="px-2 py-1 rounded-md bg-muted text-xs">{trade.strategy}</span>
                  </td>
                  <td className="px-5 py-4 text-muted-foreground text-sm hidden lg:table-cell">
                    <div>{trade.date}</div>
                    <div className="text-xs">{trade.time}</div>
                  </td>
                  <td className="px-5 py-4">
                    <div className="flex gap-1">
                      <button className="p-2 rounded-lg hover:bg-muted transition-colors">
                        <Edit3 className="h-4 w-4 text-muted-foreground" />
                      </button>
                      <button className="p-2 rounded-lg hover:bg-destructive/10 transition-colors">
                        <Trash2 className="h-4 w-4 text-muted-foreground hover:text-destructive" />
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between p-4 border-t border-border">
          <p className="text-sm text-muted-foreground">
            Showing {filteredTrades.length} of {trades.length} trades
          </p>
          <div className="flex gap-2">
            <button className="px-3 py-1.5 rounded-lg bg-muted text-sm font-medium hover:bg-muted/80 transition-colors">
              Previous
            </button>
            <button className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
              1
            </button>
            <button className="px-3 py-1.5 rounded-lg bg-muted text-sm font-medium hover:bg-muted/80 transition-colors">
              2
            </button>
            <button className="px-3 py-1.5 rounded-lg bg-muted text-sm font-medium hover:bg-muted/80 transition-colors">
              Next
            </button>
          </div>
        </div>
      </GlassCard>

      {/* Import Modal */}
      <AnimatePresence>
        {showImportModal && (
          <ImportModal onClose={() => setShowImportModal(false)} />
        )}
      </AnimatePresence>

      {/* Add Trade Modal */}
      <AnimatePresence>
        {showAddModal && (
          <AddTradeModal onClose={() => setShowAddModal(false)} />
        )}
      </AnimatePresence>
    </div>
  )
}

function FilterDropdown({ 
  value, 
  options, 
  onChange 
}: { 
  value: string
  options: string[]
  onChange: (value: string) => void 
}) {
  const [open, setOpen] = useState(false)

  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-muted/50 border border-border text-sm hover:bg-muted transition-colors min-w-[140px]"
      >
        <Filter className="h-4 w-4 text-muted-foreground" />
        <span className="flex-1 text-left">{value}</span>
        <ChevronDown className={cn("h-4 w-4 transition-transform", open && "rotate-180")} />
      </button>
      
      <AnimatePresence>
        {open && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="absolute top-full left-0 mt-2 w-full bg-card border border-border rounded-xl shadow-xl z-50 overflow-hidden"
            >
              {options.map((option) => (
                <button
                  key={option}
                  onClick={() => {
                    onChange(option)
                    setOpen(false)
                  }}
                  className={cn(
                    "w-full px-4 py-2.5 text-left text-sm hover:bg-muted transition-colors flex items-center justify-between",
                    value === option && "bg-primary/10 text-primary"
                  )}
                >
                  {option}
                  {value === option && <Check className="h-4 w-4" />}
                </button>
              ))}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}

function ImportModal({ onClose }: { onClose: () => void }) {
  const [dragActive, setDragActive] = useState(false)

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-card border border-border rounded-2xl w-full max-w-lg overflow-hidden"
      >
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="text-lg font-semibold">Import Trades</h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-muted transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Drag & Drop Area */}
          <div
            onDragOver={(e) => { e.preventDefault(); setDragActive(true) }}
            onDragLeave={() => setDragActive(false)}
            onDrop={(e) => { e.preventDefault(); setDragActive(false) }}
            className={cn(
              "border-2 border-dashed rounded-xl p-8 text-center transition-colors",
              dragActive ? "border-primary bg-primary/5" : "border-border"
            )}
          >
            <Upload className="h-10 w-10 mx-auto text-muted-foreground mb-3" />
            <p className="font-medium mb-1">Drop your file here</p>
            <p className="text-sm text-muted-foreground mb-4">or click to browse</p>
            <input type="file" className="hidden" accept=".csv,.xlsx,.html" />
            <button className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
              Select File
            </button>
          </div>

          {/* Supported Formats */}
          <div className="space-y-2">
            <p className="text-sm font-medium">Supported formats:</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { icon: FileSpreadsheet, label: 'MT5 Statement', ext: '.html' },
                { icon: FileSpreadsheet, label: 'Excel', ext: '.xlsx' },
                { icon: FileText, label: 'CSV', ext: '.csv' },
                { icon: FileText, label: 'HTML Report', ext: '.html' },
              ].map((format) => (
                <div key={format.label} className="flex items-center gap-2 p-3 rounded-xl bg-muted/50">
                  <format.icon className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm font-medium">{format.label}</p>
                    <p className="text-xs text-muted-foreground">{format.ext}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="flex gap-3 p-5 border-t border-border">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl bg-muted text-sm font-medium hover:bg-muted/80 transition-colors">
            Cancel
          </button>
          <button className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
            Import
          </button>
        </div>
      </motion.div>
    </motion.div>
  )
}

function AddTradeModal({ onClose }: { onClose: () => void }) {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-card border border-border rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden"
      >
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="text-lg font-semibold">Add New Trade</h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-muted transition-colors">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto max-h-[60vh] space-y-4">
          {/* Trade Type & Symbol */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Symbol / Pair</label>
              <select className="w-full px-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50">
                {symbols.map((symbol) => (
                  <option key={symbol} value={symbol}>{symbol}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Trade Type</label>
              <div className="flex gap-2">
                <button className="flex-1 py-2.5 rounded-xl bg-[var(--profit)]/15 text-[var(--profit)] text-sm font-medium border border-[var(--profit)]/30">
                  BUY
                </button>
                <button className="flex-1 py-2.5 rounded-xl bg-muted/50 text-muted-foreground text-sm font-medium border border-border hover:bg-muted">
                  SELL
                </button>
              </div>
            </div>
          </div>

          {/* Prices */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Entry Price</label>
              <input
                type="number"
                step="0.00001"
                placeholder="1.0845"
                className="w-full px-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Exit Price</label>
              <input
                type="number"
                step="0.00001"
                placeholder="1.0892"
                className="w-full px-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Stop Loss</label>
              <input
                type="number"
                step="0.00001"
                placeholder="1.0820"
                className="w-full px-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Take Profit</label>
              <input
                type="number"
                step="0.00001"
                placeholder="1.0920"
                className="w-full px-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
              />
            </div>
          </div>

          {/* Lot Size */}
          <div>
            <label className="block text-sm font-medium mb-2">Lot Size</label>
            <input
              type="number"
              step="0.01"
              placeholder="1.0"
              className="w-full px-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50"
            />
          </div>

          {/* Session & Strategy */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Session</label>
              <select className="w-full px-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50">
                <option>Asian</option>
                <option>London</option>
                <option>New York</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Strategy</label>
              <select className="w-full px-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50">
                <option>QML</option>
                <option>TJL 2</option>
                <option>TJL 1</option>
                <option>DT</option>
                <option>DB</option>
                <option>LVL 3</option>
                <option>LVL 4</option>
                <option>RBS</option>
                <option>SBR</option>
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium mb-2">Notes</label>
            <textarea
              rows={3}
              placeholder="Trade notes, observations, emotions..."
              className="w-full px-4 py-2.5 rounded-xl bg-muted/50 border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
            />
          </div>

          {/* Screenshot Upload */}
          <div>
            <label className="block text-sm font-medium mb-2">Screenshot</label>
            <div className="border-2 border-dashed border-border rounded-xl p-6 text-center hover:border-primary/50 transition-colors cursor-pointer">
              <Image className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">Click to upload trade screenshot</p>
            </div>
          </div>
        </div>

        <div className="flex gap-3 p-5 border-t border-border">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl bg-muted text-sm font-medium hover:bg-muted/80 transition-colors">
            Cancel
          </button>
          <button className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 transition-colors">
            Save Trade
          </button>
        </div>
      </motion.div>
    </motion.div>
  )
}
