'use client'

import { useState } from 'react'
import { motion } from 'framer-motion'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart,
  Legend,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from 'recharts'
import {
  TrendingUp,
  TrendingDown,
  Target,
  Percent,
  Scale,
  Activity,
  Calendar,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  PieChart as PieChartIcon,
  Sun,
  Moon,
  Sunrise,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { StatsCard, GlassCard, CardHeader } from '@/components/ui/stats-card'

// Mock data
const equityData = Array.from({ length: 30 }, (_, i) => ({
  day: `Day ${i + 1}`,
  balance: 10000 + Math.random() * 5000 * (1 + i * 0.03),
  pnl: (Math.random() - 0.4) * 500,
}))

const pnlDistribution = [
  { range: '-$500+', count: 3 },
  { range: '-$200', count: 8 },
  { range: '-$100', count: 15 },
  { range: '$0', count: 5 },
  { range: '+$100', count: 22 },
  { range: '+$200', count: 18 },
  { range: '+$500+', count: 12 },
]

const winLossData = [
  { name: 'Winners', value: 68, color: 'var(--profit)' },
  { name: 'Losers', value: 32, color: 'var(--loss)' },
]

const rrDistribution = [
  { rr: '< 1R', count: 15 },
  { rr: '1R', count: 25 },
  { rr: '1.5R', count: 20 },
  { rr: '2R', count: 18 },
  { rr: '2.5R', count: 12 },
  { rr: '3R+', count: 10 },
]

const dayPerformance = [
  { day: 'Mon', pnl: 450, trades: 12, winRate: 75 },
  { day: 'Tue', pnl: 320, trades: 10, winRate: 70 },
  { day: 'Wed', pnl: -180, trades: 15, winRate: 53 },
  { day: 'Thu', pnl: 580, trades: 8, winRate: 87 },
  { day: 'Fri', pnl: 220, trades: 11, winRate: 64 },
]

const sessionPerformance = [
  { session: 'Asian', trades: 45, winRate: 62, pnl: 890, avgRR: 1.4, icon: Moon, color: 'text-blue-400' },
  { session: 'London', trades: 85, winRate: 71, pnl: 2340, avgRR: 1.8, icon: Sunrise, color: 'text-orange-400' },
  { session: 'New York', trades: 72, winRate: 68, pnl: 1580, avgRR: 1.6, icon: Sun, color: 'text-yellow-400' },
]

const longShortData = [
  { metric: 'Total Trades', long: 142, short: 138 },
  { metric: 'Win Rate', long: 69, short: 65 },
  { metric: 'Avg Win', long: 185, short: 192 },
  { metric: 'Avg Loss', long: 87, short: 95 },
  { metric: 'Profit Factor', long: 2.1, short: 1.9 },
]

const radarData = [
  { metric: 'Win Rate', value: 68 },
  { metric: 'Profit Factor', value: 75 },
  { metric: 'RR Ratio', value: 82 },
  { metric: 'Consistency', value: 65 },
  { metric: 'Discipline', value: 70 },
  { metric: 'Risk Mgmt', value: 78 },
]

const calendarHeatmap = Array.from({ length: 35 }, (_, i) => ({
  day: i + 1,
  pnl: (Math.random() - 0.4) * 1000,
  trades: Math.floor(Math.random() * 10),
}))

export default function AnalyticsPage() {
  const [timeFilter, setTimeFilter] = useState('1M')

  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Analytics</h1>
          <p className="text-muted-foreground mt-1">Deep dive into your trading performance</p>
        </div>
        <div className="flex gap-1 bg-card border border-border p-1 rounded-xl">
          {['1W', '1M', '3M', '1Y', 'All'].map((filter) => (
            <button
              key={filter}
              onClick={() => setTimeFilter(filter)}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-all",
                timeFilter === filter ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              )}
            >
              {filter}
            </button>
          ))}
        </div>
      </motion.div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatsCard title="Avg Win" value="$187.42" icon={TrendingUp} changeType="positive" delay={0} />
        <StatsCard title="Avg Loss" value="$94.21" icon={TrendingDown} changeType="negative" delay={0.05} />
        <StatsCard title="Best Trade" value="+$892" icon={Target} changeType="positive" delay={0.1} />
        <StatsCard title="Worst Trade" value="-$456" icon={Activity} changeType="negative" delay={0.15} />
        <StatsCard title="Expectancy" value="$42.50" icon={Scale} changeType="positive" delay={0.2} />
        <StatsCard title="Profit Factor" value="2.14" icon={Percent} changeType="positive" delay={0.25} />
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Equity Curve */}
        <GlassCard className="min-h-[400px]" delay={0.3}>
          <CardHeader title="Equity Curve" />
          <div className="p-5 h-[320px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={equityData}>
                <defs>
                  <linearGradient id="equityGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="rgb(74, 222, 128)" stopOpacity={0.3} />
                    <stop offset="100%" stopColor="rgb(74, 222, 128)" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="day" tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={(v) => `$${(v/1000).toFixed(0)}k`} />
                <Tooltip contentStyle={{ backgroundColor: 'rgba(20, 24, 32, 0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }} />
                <Area type="monotone" dataKey="balance" stroke="rgb(74, 222, 128)" strokeWidth={2} fill="url(#equityGradient)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        {/* P&L Distribution */}
        <GlassCard className="min-h-[400px]" delay={0.35}>
          <CardHeader title="P&L Distribution" />
          <div className="p-5 h-[320px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={pnlDistribution}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="range" tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ backgroundColor: 'rgba(20, 24, 32, 0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }} />
                <Bar dataKey="count" fill="rgb(74, 222, 128)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>
      </div>

      {/* Win/Loss & RR Distribution */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Win/Loss Pie */}
        <GlassCard className="min-h-[350px]" delay={0.4}>
          <CardHeader title="Win vs Loss" />
          <div className="p-5 h-[270px] flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={winLossData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {winLossData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color === 'var(--profit)' ? 'rgb(74, 222, 128)' : 'rgb(248, 113, 113)'} />
                  ))}
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: 'rgba(20, 24, 32, 0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="px-5 pb-5 flex justify-center gap-6">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[var(--profit)]" />
              <span className="text-sm">Winners (68%)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-[var(--loss)]" />
              <span className="text-sm">Losers (32%)</span>
            </div>
          </div>
        </GlassCard>

        {/* RR Distribution */}
        <GlassCard className="min-h-[350px]" delay={0.45}>
          <CardHeader title="Risk:Reward Distribution" />
          <div className="p-5 h-[270px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={rrDistribution} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis type="number" tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="rr" tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 11 }} axisLine={false} tickLine={false} width={50} />
                <Tooltip contentStyle={{ backgroundColor: 'rgba(20, 24, 32, 0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }} />
                <Bar dataKey="count" fill="rgb(96, 165, 250)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        {/* Performance Radar */}
        <GlassCard className="min-h-[350px]" delay={0.5}>
          <CardHeader title="Performance Score" />
          <div className="p-5 h-[270px]">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData}>
                <PolarGrid stroke="rgba(255,255,255,0.1)" />
                <PolarAngleAxis dataKey="metric" tick={{ fill: 'rgba(255,255,255,0.6)', fontSize: 10 }} />
                <PolarRadiusAxis tick={{ fill: 'rgba(255,255,255,0.4)', fontSize: 10 }} domain={[0, 100]} />
                <Radar name="Score" dataKey="value" stroke="rgb(74, 222, 128)" fill="rgb(74, 222, 128)" fillOpacity={0.3} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>
      </div>

      {/* Long vs Short Analytics */}
      <GlassCard delay={0.55}>
        <CardHeader title="Long vs Short Performance" />
        <div className="p-5">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {longShortData.map((item, index) => (
              <motion.div
                key={item.metric}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.55 + index * 0.05 }}
                className="p-4 rounded-xl bg-muted/30"
              >
                <p className="text-sm text-muted-foreground mb-3">{item.metric}</p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <ArrowUpRight className="h-4 w-4 text-[var(--profit)]" />
                    <span className="font-semibold">{typeof item.long === 'number' && item.metric.includes('Rate') ? `${item.long}%` : item.long}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ArrowDownRight className="h-4 w-4 text-[var(--loss)]" />
                    <span className="font-semibold">{typeof item.short === 'number' && item.metric.includes('Rate') ? `${item.short}%` : item.short}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </GlassCard>

      {/* Day & Session Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Day Performance */}
        <GlassCard className="min-h-[400px]" delay={0.6}>
          <CardHeader title="Performance by Day" />
          <div className="p-5 h-[320px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={dayPerformance}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="day" tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: 'rgba(255,255,255,0.5)', fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={{ backgroundColor: 'rgba(20, 24, 32, 0.95)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }} />
                <Bar dataKey="pnl" radius={[4, 4, 0, 0]}>
                  {dayPerformance.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.pnl >= 0 ? 'rgb(74, 222, 128)' : 'rgb(248, 113, 113)'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        {/* Session Performance */}
        <GlassCard className="min-h-[400px]" delay={0.65}>
          <CardHeader title="Performance by Session" />
          <div className="p-5 space-y-4">
            {sessionPerformance.map((session, index) => (
              <motion.div
                key={session.session}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.65 + index * 0.1 }}
                className="p-4 rounded-xl bg-muted/30 border border-border"
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={cn("p-2 rounded-lg bg-muted", session.color)}>
                      <session.icon className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="font-semibold">{session.session} Session</h4>
                      <p className="text-sm text-muted-foreground">{session.trades} trades</p>
                    </div>
                  </div>
                  <div className={cn(
                    "text-xl font-bold",
                    session.pnl >= 0 ? "text-[var(--profit)]" : "text-[var(--loss)]"
                  )}>
                    {session.pnl >= 0 ? '+' : ''}${session.pnl}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Win Rate</p>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-[var(--profit)] rounded-full"
                          style={{ width: `${session.winRate}%` }}
                        />
                      </div>
                      <span className="text-sm font-medium">{session.winRate}%</span>
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Avg RR</p>
                    <p className="text-sm font-medium">{session.avgRR}R</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* Calendar Heatmap */}
      <GlassCard delay={0.7}>
        <CardHeader title="Trading Calendar Heatmap" />
        <div className="p-5">
          <div className="grid grid-cols-7 gap-2">
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((day) => (
              <div key={day} className="text-center text-xs text-muted-foreground py-2">
                {day}
              </div>
            ))}
            {calendarHeatmap.map((day, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.7 + index * 0.01 }}
                className={cn(
                  "aspect-square rounded-lg flex items-center justify-center text-xs font-medium transition-all cursor-pointer hover:ring-2 hover:ring-primary/30",
                  day.trades === 0 ? "bg-muted/30 text-muted-foreground" :
                  day.pnl > 500 ? "bg-[var(--profit)] text-[var(--profit)]-foreground" :
                  day.pnl > 0 ? "bg-[var(--profit)]/50 text-foreground" :
                  day.pnl > -500 ? "bg-[var(--loss)]/50 text-foreground" :
                  "bg-[var(--loss)] text-[var(--loss)]-foreground"
                )}
                title={`P&L: $${day.pnl.toFixed(0)} | Trades: ${day.trades}`}
              >
                {day.day}
              </motion.div>
            ))}
          </div>
          <div className="flex items-center justify-center gap-4 mt-4 pt-4 border-t border-border">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-[var(--loss)]" />
              <span className="text-xs text-muted-foreground">Big Loss</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-[var(--loss)]/50" />
              <span className="text-xs text-muted-foreground">Small Loss</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-muted/30" />
              <span className="text-xs text-muted-foreground">No Trades</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-[var(--profit)]/50" />
              <span className="text-xs text-muted-foreground">Small Win</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-[var(--profit)]" />
              <span className="text-xs text-muted-foreground">Big Win</span>
            </div>
          </div>
        </div>
      </GlassCard>
    </div>
  )
}
