'use client'

import { motion } from 'framer-motion'
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  Target,
  Percent,
  Scale,
  BarChart2,
  Activity,
  Calendar,
  Clock,
  Sparkles
} from 'lucide-react'
import { StatsCard, GlassCard } from '@/components/ui/stats-card'
import { EquityCurve } from '@/components/charts/equity-curve'
import { TradingCalendar } from '@/components/charts/trading-calendar'
import { RecentTrades } from '@/components/tables/recent-trades'
import { PerformanceWidgets } from '@/components/widgets/performance-widgets'

const stats = [
  { title: 'Current Balance', value: '$24,847.32', change: '+12.4%', changeType: 'positive' as const, icon: Wallet },
  { title: 'Total P&L', value: '+$4,847.32', change: '+24.2%', changeType: 'positive' as const, icon: TrendingUp },
  { title: 'Daily P&L', value: '+$342.50', change: '+1.4%', changeType: 'positive' as const, icon: Activity },
  { title: 'Weekly P&L', value: '+$1,247.80', change: '+5.2%', changeType: 'positive' as const, icon: Calendar },
  { title: 'Monthly P&L', value: '+$3,892.45', change: '+18.7%', changeType: 'positive' as const, icon: BarChart2 },
  { title: 'Win Rate', value: '67.8%', change: '+2.3%', changeType: 'positive' as const, icon: Target },
  { title: 'Avg Win', value: '$187.42', change: null, changeType: 'positive' as const, icon: TrendingUp },
  { title: 'Avg Loss', value: '$94.21', change: null, changeType: 'negative' as const, icon: TrendingDown },
  { title: 'Profit Factor', value: '2.14', change: '+0.3', changeType: 'positive' as const, icon: Scale },
  { title: 'Risk/Reward', value: '1:1.98', change: null, changeType: 'neutral' as const, icon: Percent },
  { title: 'Total Trades', value: '284', change: '+12 this week', changeType: 'neutral' as const, icon: Clock },
]

export default function DashboardPage() {
  return (
    <div className="p-4 lg:p-8 space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
      >
        <div>
          <h1 className="text-2xl lg:text-3xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Welcome back! Here&apos;s your trading overview.</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-medium text-sm hover:bg-primary/90 transition-colors"
        >
          <Sparkles className="h-4 w-4" />
          AI Insights
        </motion.button>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        {stats.slice(0, 6).map((stat, index) => (
          <StatsCard
            key={stat.title}
            title={stat.title}
            value={stat.value}
            change={stat.change || undefined}
            changeType={stat.changeType}
            icon={stat.icon}
            delay={index * 0.05}
          />
        ))}
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4">
        {stats.slice(6).map((stat, index) => (
          <StatsCard
            key={stat.title}
            title={stat.title}
            value={stat.value}
            change={stat.change || undefined}
            changeType={stat.changeType}
            icon={stat.icon}
            delay={0.3 + index * 0.05}
          />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Equity Curve - Takes 2 columns */}
        <GlassCard className="xl:col-span-2 min-h-[450px]" delay={0.4}>
          <EquityCurve />
        </GlassCard>

        {/* Trading Calendar */}
        <GlassCard className="min-h-[450px]" delay={0.5}>
          <TradingCalendar />
        </GlassCard>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Trades - Takes 2 columns */}
        <GlassCard className="lg:col-span-2 min-h-[400px]" delay={0.6}>
          <RecentTrades />
        </GlassCard>

        {/* Performance Widgets */}
        <GlassCard className="min-h-[400px]" delay={0.7}>
          <PerformanceWidgets />
        </GlassCard>
      </div>
    </div>
  )
}
