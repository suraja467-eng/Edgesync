import { GoogleGenerativeAI } from '@google/generative-ai'
import { NextRequest, NextResponse } from 'next/server'

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || '')

export async function POST(request: NextRequest) {
  try {
    const { tradingData, reportType } = await request.json()

    if (!process.env.GEMINI_API_KEY) {
      return NextResponse.json(
        { error: 'Gemini API key not configured' },
        { status: 500 }
      )
    }

    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' })

    const prompts: Record<string, string> = {
      performance: `You are an expert trading coach and analyst. Analyze the following trading data and provide a comprehensive performance report.

Trading Data:
${JSON.stringify(tradingData, null, 2)}

Provide a detailed report including:
1. **Overall Performance Summary** - Key metrics and their interpretation
2. **Strengths Analysis** - What the trader is doing well
3. **Weaknesses Identified** - Areas that need improvement
4. **Risk Management Assessment** - Evaluation of position sizing, stop losses, and risk/reward ratios
5. **Pattern Recognition** - Any patterns in winning vs losing trades
6. **Actionable Recommendations** - Specific steps to improve performance

Format your response with clear headings and bullet points. Be specific and data-driven in your analysis.`,

      psychology: `You are a trading psychology expert. Analyze the following trading data to assess the trader's psychological patterns and emotional discipline.

Trading Data:
${JSON.stringify(tradingData, null, 2)}

Provide a psychological assessment including:
1. **Emotional Patterns** - Signs of fear, greed, or revenge trading
2. **Discipline Score** - How well the trader sticks to their plan
3. **Stress Points** - Times when emotions might have affected decisions
4. **Mindset Strengths** - Positive psychological traits observed
5. **Areas for Mental Improvement** - Psychological skills to develop
6. **Daily Routine Suggestions** - Practices to improve trading psychology

Be empathetic but honest in your assessment.`,

      strategy: `You are a quantitative trading strategist. Analyze the following trading data to evaluate the trading strategy effectiveness.

Trading Data:
${JSON.stringify(tradingData, null, 2)}

Provide a strategy analysis including:
1. **Strategy Effectiveness** - Win rate, profit factor, expectancy analysis
2. **Best Performing Setups** - Which conditions yield the best results
3. **Worst Performing Setups** - Setups to avoid or refine
4. **Market Condition Analysis** - How different market conditions affect results
5. **Session Performance** - Best and worst trading sessions
6. **Optimization Suggestions** - Specific strategy refinements to consider

Include statistical insights where relevant.`,

      weekly: `You are a trading journal analyst. Create a comprehensive weekly trading report based on the following data.

Trading Data:
${JSON.stringify(tradingData, null, 2)}

Provide a weekly report including:
1. **Week at a Glance** - Summary of key metrics
2. **Best Trade Analysis** - Deep dive into the most profitable trade
3. **Worst Trade Analysis** - What went wrong and lessons learned
4. **Progress vs Previous Week** - Comparative analysis
5. **Goals Check** - Are we on track with trading goals?
6. **Focus Areas for Next Week** - What to concentrate on
7. **Risk Exposure Summary** - Portfolio risk assessment

Make it actionable and motivating.`,

      custom: `You are an expert trading analyst. Based on the following trading data, provide insights and analysis.

Trading Data:
${JSON.stringify(tradingData, null, 2)}

Provide comprehensive analysis with actionable insights. Focus on patterns, strengths, weaknesses, and specific recommendations for improvement.`
    }

    const prompt = prompts[reportType] || prompts.custom

    const result = await model.generateContent(prompt)
    const response = await result.response
    const text = response.text()

    return NextResponse.json({ report: text })
  } catch (error) {
    console.error('AI Report generation error:', error)
    return NextResponse.json(
      { error: 'Failed to generate report' },
      { status: 500 }
    )
  }
}
